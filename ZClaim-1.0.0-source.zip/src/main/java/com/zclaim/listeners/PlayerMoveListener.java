package com.zclaim.listeners;

import com.zclaim.ZClaim;
import com.zclaim.models.Claim;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Yalnızca chunk değiştiğinde claim geçişini kontrol eder; claim değişmedikçe bildirim göndermez. */
public final class PlayerMoveListener implements Listener {

    private final ZClaim plugin;
    /** Oyuncunun son bulunduğu claim ID'si (-1: claim yok). */
    private final Map<UUID, Integer> lastClaim = new HashMap<>();

    public PlayerMoveListener(ZClaim plugin) {
        this.plugin = plugin;
    }

    public void initOnlinePlayers() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            lastClaim.put(p.getUniqueId(), claimId(p.getLocation()));
        }
    }

    private int claimId(Location loc) {
        Claim c = plugin.claims().getClaimAt(loc);
        return c == null ? -1 : c.getId();
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) {
            return;
        }
        // Hızlı çıkış: blok koordinatı değişmediyse hiçbir şey yapma
        if (from.getBlockX() == to.getBlockX() && from.getBlockZ() == to.getBlockZ()
                && from.getWorld() == to.getWorld()) {
            return;
        }
        if ((from.getBlockX() >> 4) == (to.getBlockX() >> 4)
                && (from.getBlockZ() >> 4) == (to.getBlockZ() >> 4)
                && from.getWorld() == to.getWorld()) {
            return;
        }
        update(e.getPlayer(), to);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        update(e.getPlayer(), e.getTo());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        lastClaim.put(e.getPlayer().getUniqueId(), claimId(e.getPlayer().getLocation()));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID uuid = e.getPlayer().getUniqueId();
        lastClaim.remove(uuid);
        plugin.protection().forget(uuid);
        plugin.borders().stop(uuid);
        plugin.claims().forget(uuid);
        plugin.gui().forget(uuid);
    }

    private void update(Player p, Location to) {
        Claim claim = plugin.claims().getClaimAt(to);
        int id = claim == null ? -1 : claim.getId();
        Integer previous = lastClaim.put(p.getUniqueId(), id);
        if (claim == null || (previous != null && previous == id)) {
            return;
        }
        UUID uuid = p.getUniqueId();
        if (claim.isOwner(uuid)) {
            return;
        }
        boolean trusted = claim.getTrustMask(uuid) != 0;
        if (trusted && !plugin.getConfig().getBoolean("notifications.enter-claim.notify-trusted", false)) {
            return;
        }
        plugin.messages().title(p, "enter-claim", "owner", claim.getOwnerName());
    }
}
