package com.zclaim.listeners;

import com.zclaim.ZClaim;
import com.zclaim.gui.ZGui;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

public final class GUIListener implements Listener {

    private final ZClaim plugin;

    public GUIListener(ZClaim plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder(false) instanceof ZGui gui)) {
            return;
        }
        // Menü açıkken hiçbir item hareketine izin verilmez (shift-click, sayı tuşu, çift tık dahil).
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) {
            return;
        }
        Inventory clicked = e.getClickedInventory();
        if (clicked == null || !clicked.equals(top)) {
            return;
        }
        ClickType type = e.getClick();
        if (type != ClickType.LEFT && type != ClickType.RIGHT
                && type != ClickType.SHIFT_LEFT && type != ClickType.SHIFT_RIGHT) {
            return;
        }
        if (plugin.gui().throttle(p.getUniqueId())) {
            return;
        }
        gui.click(p, e.getSlot(), type);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder(false) instanceof ZGui) {
            e.setCancelled(true);
        }
    }
}
