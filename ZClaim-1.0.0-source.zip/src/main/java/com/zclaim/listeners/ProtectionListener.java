package com.zclaim.listeners;

import com.zclaim.ZClaim;
import com.zclaim.managers.ClaimManager;
import com.zclaim.managers.ProtectionManager;
import com.zclaim.models.Claim;
import com.zclaim.models.ClaimPermission;
import com.zclaim.models.ClaimSettings.Flag;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.entity.AbstractVillager;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.Entity;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Hanging;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Tameable;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.Vehicle;
import org.bukkit.entity.minecart.ExplosiveMinecart;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockDispenseEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockMultiPlaceEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityInteractEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.hanging.HangingBreakEvent;
import org.bukkit.event.hanging.HangingPlaceEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.vehicle.VehicleDamageEvent;
import org.bukkit.event.world.StructureGrowEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.EnumSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

/**
 * Tüm claim koruma olayları. Claim sorgusu bellekteki (dünya UUID + chunk) haritasından O(1) yapılır;
 * olay işleyicilerinde SQL çalıştırılmaz.
 */
public final class ProtectionListener implements Listener {

    private static final Set<Material> BUILD_INTERACT = EnumSet.of(
            Material.DRAGON_EGG, Material.COMPOSTER, Material.BEEHIVE, Material.BEE_NEST,
            Material.SWEET_BERRY_BUSH, Material.CAVE_VINES, Material.CAVE_VINES_PLANT,
            Material.RESPAWN_ANCHOR, Material.FLOWER_POT, Material.REPEATER, Material.COMPARATOR,
            Material.DAYLIGHT_DETECTOR);

    private static final Set<Material> WORLD_ITEMS = EnumSet.of(
            Material.BONE_MEAL, Material.ARMOR_STAND, Material.END_CRYSTAL, Material.ITEM_FRAME,
            Material.GLOW_ITEM_FRAME, Material.PAINTING, Material.FLINT_AND_STEEL, Material.FIRE_CHARGE,
            Material.GLOW_INK_SAC, Material.INK_SAC, Material.HONEYCOMB, Material.BRUSH, Material.SHEARS,
            Material.LEAD, Material.ENDER_EYE);

    private static final Set<String> HOSTILE_SPAWN_REASONS = Set.of(
            "NATURAL", "SPAWNER", "JOCKEY", "REINFORCEMENTS", "TRAP", "VILLAGE_INVASION",
            "PATROL", "RAID", "SILVERFISH_BLOCK", "LIGHTNING");

    private final ZClaim plugin;
    private final ClaimManager claims;
    private final ProtectionManager prot;

    public ProtectionListener(ZClaim plugin) {
        this.plugin = plugin;
        this.claims = plugin.claims();
        this.prot = plugin.protection();
    }

    // ------------------------------------------------------------------ yardımcılar

    private static boolean sameOwner(Claim a, Claim b) {
        UUID oa = a == null ? null : a.getOwnerUuid();
        UUID ob = b == null ? null : b.getOwnerUuid();
        return Objects.equals(oa, ob);
    }

    private static Player playerOf(Entity e) {
        if (e instanceof Player p) {
            return p;
        }
        if (e instanceof Projectile pr && pr.getShooter() instanceof Player p) {
            return p;
        }
        return null;
    }

    private static boolean isProtectedEntity(Entity e) {
        if (e instanceof Player || e instanceof Enemy) {
            return false;
        }
        return e instanceof LivingEntity || e instanceof Hanging || e instanceof Vehicle;
    }

    private static boolean isOwnPet(Entity e, Player p) {
        return e instanceof Tameable t && t.isTamed() && t.getOwner() != null
                && t.getOwner().getUniqueId().equals(p.getUniqueId());
    }

    private static ClaimPermission entityPermission(Entity e) {
        if (e instanceof AbstractVillager) {
            return ClaimPermission.ACCESS;
        }
        if (e instanceof InventoryHolder) {
            return ClaimPermission.CONTAINER;
        }
        return ClaimPermission.BUILD;
    }

    private boolean explosionAllowed(Entity source, Claim claim) {
        if (claim.isServerOwned()) {
            return false;
        }
        if (source instanceof TNTPrimed || source instanceof ExplosiveMinecart) {
            return claim.getSettings().get(Flag.TNT_EXPLOSIONS);
        }
        if (source instanceof Creeper) {
            return claim.getSettings().get(Flag.CREEPER_EXPLOSIONS);
        }
        return claim.getSettings().get(Flag.MOB_GRIEFING);
    }

    private static boolean isWorldItem(Material m) {
        if (WORLD_ITEMS.contains(m)) {
            return true;
        }
        String n = m.name();
        return n.endsWith("_SPAWN_EGG") || n.endsWith("_HOE") || n.endsWith("_SHOVEL") || n.endsWith("_AXE")
                || n.endsWith("_DYE") || n.endsWith("_BOAT") || n.endsWith("_RAFT") || n.endsWith("MINECART")
                || (n.endsWith("_BUCKET") && m != Material.BUCKET);
    }

    /** Sağ tıklanan bloğun gerektirdiği yetki; null = serbest. */
    private ClaimPermission blockPermission(Block b) {
        Material m = b.getType();
        if (m == Material.ENDER_CHEST || !m.isInteractable()) {
            return null;
        }
        String n = m.name();
        if (n.endsWith("_SIGN") || n.endsWith("_HANGING_SIGN") || n.contains("CAULDRON")
                || n.startsWith("POTTED_") || BUILD_INTERACT.contains(m)) {
            return ClaimPermission.BUILD;
        }
        if (m == Material.JUKEBOX || b.getState(false) instanceof Container) {
            return ClaimPermission.CONTAINER;
        }
        return ClaimPermission.ACCESS;
    }

    // ------------------------------------------------------------------ blok işlemleri

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (prot.blockBreak && !prot.check(e.getPlayer(), e.getBlock(), ClaimPermission.BUILD)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (!prot.blockPlace) {
            return;
        }
        Player p = e.getPlayer();
        if (!prot.check(p, e.getBlockPlaced(), ClaimPermission.BUILD)) {
            e.setCancelled(true);
            return;
        }
        if (e instanceof BlockMultiPlaceEvent multi) {
            for (BlockState s : multi.getReplacedBlockStates()) {
                if (!prot.check(p, s.getBlock(), ClaimPermission.BUILD)) {
                    e.setCancelled(true);
                    return;
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        if (prot.blockPlace && !prot.check(e.getPlayer(), e.getBlock(), ClaimPermission.BUILD)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        if (prot.blockBreak && !prot.check(e.getPlayer(), e.getBlock(), ClaimPermission.BUILD)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSign(SignChangeEvent e) {
        if (prot.interactions && !prot.check(e.getPlayer(), e.getBlock(), ClaimPermission.BUILD)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onIgnite(BlockIgniteEvent e) {
        Claim c = claims.getClaimAt(e.getBlock());
        if (c == null) {
            return;
        }
        Player p = e.getPlayer();
        if (p != null) {
            if (prot.blockPlace && !prot.check(p, c, ClaimPermission.BUILD)) {
                e.setCancelled(true);
            }
            return;
        }
        if (prot.fireSpread && (c.isServerOwned() || !c.getSettings().get(Flag.FIRE_SPREAD))) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBurn(BlockBurnEvent e) {
        if (!prot.fireSpread) {
            return;
        }
        Claim c = claims.getClaimAt(e.getBlock());
        if (c != null && (c.isServerOwned() || !c.getSettings().get(Flag.FIRE_SPREAD))) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFlow(BlockFromToEvent e) {
        if (claims.isEmpty()) {
            return;
        }
        Block from = e.getBlock();
        Block to = e.getToBlock();
        Claim cTo = claims.getClaimAt(to);
        boolean sameChunk = (from.getX() >> 4) == (to.getX() >> 4) && (from.getZ() >> 4) == (to.getZ() >> 4);
        Claim cFrom = sameChunk ? cTo : claims.getClaimAt(from);
        if (cTo == null && cFrom == null) {
            return;
        }
        if (cTo != null && !sameOwner(cFrom, cTo)) {
            e.setCancelled(true); // dışarıdan claim içine akış yok
            return;
        }
        if (cTo != null && !cTo.getSettings().get(Flag.FLUID_FLOW)) {
            e.setCancelled(true);
        } else if (cFrom != null && !cFrom.getSettings().get(Flag.FLUID_FLOW)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onStructureGrow(StructureGrowEvent e) {
        if (claims.isEmpty()) {
            return;
        }
        Claim origin = claims.getClaimAt(e.getLocation());
        e.getBlocks().removeIf(s -> !sameOwner(origin, claims.getClaimAt(s.getLocation())));
    }

    // ------------------------------------------------------------------ etkileşimler

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        Block b = e.getClickedBlock();
        if (b == null) {
            return;
        }
        Claim c = claims.getClaimAt(b);
        if (c == null) {
            return;
        }
        Player p = e.getPlayer();
        Action action = e.getAction();
        Material type = b.getType();

        if (action == Action.PHYSICAL) {
            if (!prot.interactions) {
                return;
            }
            ClaimPermission need = null;
            if (type == Material.FARMLAND || type == Material.TURTLE_EGG) {
                need = ClaimPermission.BUILD;
            } else if (type.name().endsWith("_PRESSURE_PLATE") || type == Material.TRIPWIRE) {
                need = ClaimPermission.ACCESS;
            }
            if (need != null && !prot.canAct(p, c, need)) {
                e.setCancelled(true); // sessiz: yürürken sürekli mesaj gönderilmez
            }
            return;
        }

        boolean dragonEggPunch = action == Action.LEFT_CLICK_BLOCK && type == Material.DRAGON_EGG;
        if (action != Action.RIGHT_CLICK_BLOCK && !dragonEggPunch) {
            return;
        }

        ClaimPermission need = blockPermission(b);
        if (need != null) {
            boolean enabled = need == ClaimPermission.CONTAINER ? prot.containers : prot.interactions;
            if (enabled && !prot.check(p, c, need)) {
                e.setCancelled(true);
                return;
            }
        }
        ItemStack hand = e.getItem();
        if (prot.interactions && hand != null && isWorldItem(hand.getType())
                && !prot.check(p, c, ClaimPermission.BUILD)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (!prot.interactions) {
            return;
        }
        Entity target = e.getRightClicked();
        if (!isProtectedEntity(target)) {
            return;
        }
        Claim c = claims.getClaimAt(target.getLocation());
        if (c == null) {
            return;
        }
        Player p = e.getPlayer();
        if (isOwnPet(target, p)) {
            return;
        }
        if (!prot.check(p, c, entityPermission(target))) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onArmorStand(PlayerArmorStandManipulateEvent e) {
        if (!prot.interactions) {
            return;
        }
        if (!prot.check(e.getPlayer(), e.getRightClicked().getLocation(), ClaimPermission.BUILD)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFish(PlayerFishEvent e) {
        if (!prot.entityDamage || e.getState() != PlayerFishEvent.State.CAUGHT_ENTITY) {
            return;
        }
        Entity caught = e.getCaught();
        if (caught == null || !isProtectedEntity(caught)) {
            return;
        }
        Claim c = claims.getClaimAt(caught.getLocation());
        if (c != null && !isOwnPet(caught, e.getPlayer()) && !prot.check(e.getPlayer(), c, ClaimPermission.BUILD)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHangingPlace(HangingPlaceEvent e) {
        Player p = e.getPlayer();
        if (p != null && prot.blockPlace && !prot.check(p, e.getBlock(), ClaimPermission.BUILD)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHangingBreak(HangingBreakEvent e) {
        Claim c = claims.getClaimAt(e.getEntity().getLocation());
        if (c == null) {
            return;
        }
        if (e instanceof HangingBreakByEntityEvent byEntity) {
            Entity remover = byEntity.getRemover();
            Player p = remover == null ? null : playerOf(remover);
            if (p != null) {
                if (prot.entityDamage && !prot.check(p, c, ClaimPermission.BUILD)) {
                    e.setCancelled(true);
                }
                return;
            }
            if (prot.explosions && remover != null && !explosionAllowed(remover, c)
                    && e.getCause() == HangingBreakEvent.RemoveCause.EXPLOSION) {
                e.setCancelled(true);
            }
            return;
        }
        if (prot.explosions && e.getCause() == HangingBreakEvent.RemoveCause.EXPLOSION) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onVehicleDamage(VehicleDamageEvent e) {
        Entity attacker = e.getAttacker();
        Player p = attacker == null ? null : playerOf(attacker);
        if (p == null || !prot.entityDamage) {
            return;
        }
        Claim c = claims.getClaimAt(e.getVehicle().getLocation());
        if (c != null && !prot.check(p, c, ClaimPermission.BUILD)) {
            e.setCancelled(true);
        }
    }

    // ------------------------------------------------------------------ hasar / PvP

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamageByEntity(EntityDamageByEntityEvent e) {
        Entity victim = e.getEntity();
        Claim c = claims.getClaimAt(victim.getLocation());
        if (c == null) {
            return;
        }
        Entity damager = e.getDamager();
        Player attacker = playerOf(damager);

        if (victim instanceof Player victimPlayer) {
            if (attacker != null && !attacker.equals(victimPlayer)
                    && !c.getSettings().get(Flag.PVP) && !prot.isBypassing(attacker)) {
                e.setCancelled(true);
                plugin.messages().send(attacker, "protection.pvp-disabled");
            }
            return;
        }
        if (!isProtectedEntity(victim)) {
            return;
        }
        if (attacker != null) {
            if (prot.entityDamage && !isOwnPet(victim, attacker) && !prot.check(attacker, c, ClaimPermission.BUILD)) {
                e.setCancelled(true);
            }
            return;
        }
        if (prot.explosions
                && (e.getCause() == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION)
                && !explosionAllowed(damager, c)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (e instanceof EntityDamageByEntityEvent || !prot.explosions
                || e.getCause() != EntityDamageEvent.DamageCause.BLOCK_EXPLOSION) {
            return;
        }
        if (isProtectedEntity(e.getEntity()) && claims.getClaimAt(e.getEntity().getLocation()) != null) {
            e.setCancelled(true);
        }
    }

    // ------------------------------------------------------------------ patlamalar

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        if (!prot.explosions || claims.isEmpty()) {
            return;
        }
        Entity source = e.getEntity();
        e.blockList().removeIf(b -> {
            Claim c = claims.getClaimAt(b);
            return c != null && !explosionAllowed(source, c);
        });
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        if (!prot.explosions || claims.isEmpty()) {
            return;
        }
        e.blockList().removeIf(b -> claims.getClaimAt(b) != null);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityChangeBlock(EntityChangeBlockEvent e) {
        Entity ent = e.getEntity();
        if (ent instanceof Player || ent instanceof FallingBlock) {
            return;
        }
        Claim c = claims.getClaimAt(e.getBlock());
        if (c != null && (c.isServerOwned() || !c.getSettings().get(Flag.MOB_GRIEFING))) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityInteract(EntityInteractEvent e) {
        Material t = e.getBlock().getType();
        if (t != Material.FARMLAND && t != Material.TURTLE_EGG) {
            return;
        }
        Claim c = claims.getClaimAt(e.getBlock());
        if (c != null && (c.isServerOwned() || !c.getSettings().get(Flag.MOB_GRIEFING))) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent e) {
        if (claims.isEmpty() || !(e.getEntity() instanceof Enemy)
                || !HOSTILE_SPAWN_REASONS.contains(e.getSpawnReason().name())) {
            return;
        }
        Claim c = claims.getClaimAt(e.getLocation());
        if (c != null && !c.getSettings().get(Flag.MOB_SPAWNING)) {
            e.setCancelled(true);
        }
    }

    // ------------------------------------------------------------------ piston / hopper / dispenser

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        if (prot.pistons && pistonCrossesClaim(e.getBlock(), e.getDirection(), e.getBlocks())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        if (prot.pistons && pistonCrossesClaim(e.getBlock(), e.getDirection(), e.getBlocks())) {
            e.setCancelled(true);
        }
    }

    private boolean pistonCrossesClaim(Block piston, BlockFace dir, java.util.List<Block> moved) {
        if (claims.isEmpty()) {
            return false;
        }
        Claim home = claims.getClaimAt(piston);
        if (!sameOwner(home, claims.getClaimAt(piston.getRelative(dir)))) {
            return true;
        }
        BlockFace opposite = dir.getOppositeFace();
        for (Block b : moved) {
            if (!sameOwner(home, claims.getClaimAt(b))
                    || !sameOwner(home, claims.getClaimAt(b.getRelative(dir)))
                    || !sameOwner(home, claims.getClaimAt(b.getRelative(opposite)))) {
                return true;
            }
        }
        return false;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHopperMove(InventoryMoveItemEvent e) {
        if (!prot.containers || claims.isEmpty()) {
            return;
        }
        org.bukkit.Location s = e.getSource().getLocation();
        org.bukkit.Location d = e.getDestination().getLocation();
        Claim cs = s == null ? null : claims.getClaimAt(s);
        Claim cd = d == null ? null : claims.getClaimAt(d);
        if ((cs != null || cd != null) && !sameOwner(cs, cd)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDispense(BlockDispenseEvent e) {
        if (!prot.containers || claims.isEmpty()) {
            return;
        }
        Block block = e.getBlock();
        BlockData data = block.getBlockData();
        if (!(data instanceof Directional dir)) {
            return;
        }
        Claim target = claims.getClaimAt(block.getRelative(dir.getFacing()));
        if (target != null && !sameOwner(claims.getClaimAt(block), target)) {
            e.setCancelled(true);
        }
    }
}
