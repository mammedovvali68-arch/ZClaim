package com.zclaim.utils;

import com.zclaim.ZClaim;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;

public final class MessageUtils {

    private static final LegacyComponentSerializer LEGACY =
            LegacyComponentSerializer.builder().character('&').hexColors().build();
    private static final DateTimeFormatter DATE =
            DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm").withZone(ZoneId.systemDefault());

    private final ZClaim plugin;

    public MessageUtils(ZClaim plugin) {
        this.plugin = plugin;
    }

    public static Component color(String text) {
        return LEGACY.deserialize(text == null ? "" : text);
    }

    /** Item adı/lore için italik kapalı bileşen. */
    public static Component item(String text) {
        return color(text).decoration(TextDecoration.ITALIC, false);
    }

    public static String date(long millis) {
        return DATE.format(Instant.ofEpochMilli(millis));
    }

    /** kv: anahtar, değer, anahtar, değer... şeklinde {anahtar} yer tutucularını değiştirir. */
    public static String apply(String text, String... kv) {
        if (text == null) {
            return "";
        }
        for (int i = 0; i + 1 < kv.length; i += 2) {
            text = text.replace("{" + kv[i] + "}", kv[i + 1] == null ? "" : kv[i + 1]);
        }
        return text;
    }

    public String raw(String path) {
        return plugin.getConfig().getString("messages." + path, "&cEksik mesaj: " + path);
    }

    public String get(String path, String... kv) {
        return apply(raw(path), kv);
    }

    public List<String> list(String path) {
        return plugin.getConfig().getStringList("messages." + path);
    }

    private String prefix() {
        return plugin.getConfig().getString("messages.prefix", "");
    }

    public void send(CommandSender to, String path, String... kv) {
        String text = get(path, kv);
        if (text.isEmpty()) {
            return;
        }
        to.sendMessage(color(prefix() + text));
    }

    public void sendLines(CommandSender to, String path, String... kv) {
        for (String line : list(path)) {
            to.sendMessage(color(apply(line, kv)));
        }
    }

    /** notifications.<path> bölümünden Title gösterir. */
    public void title(Player player, String path, String... kv) {
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("notifications." + path);
        if (sec == null || !sec.getBoolean("enabled", true)) {
            return;
        }
        Title.Times times = Title.Times.times(
                Duration.ofMillis(sec.getInt("fade-in", 10) * 50L),
                Duration.ofMillis(sec.getInt("stay", 40) * 50L),
                Duration.ofMillis(sec.getInt("fade-out", 10) * 50L));
        player.showTitle(Title.title(
                color(apply(sec.getString("title", ""), kv)),
                color(apply(sec.getString("subtitle", ""), kv)),
                times));
    }
}
