package com.zclaim.utils;

public final class ChunkUtils {

    private ChunkUtils() {
    }

    /** Chunk X/Z değerlerinden tek bir long anahtar üretir (dünya UUID'si ile birlikte benzersiz claim anahtarı). */
    public static long key(int chunkX, int chunkZ) {
        return ((long) chunkX << 32) | (chunkZ & 0xFFFFFFFFL);
    }
}
