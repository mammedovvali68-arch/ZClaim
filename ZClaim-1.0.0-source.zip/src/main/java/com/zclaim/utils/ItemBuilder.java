package com.zclaim.utils;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class ItemBuilder {

    private final Material material;
    private String name;
    private List<String> lore = new ArrayList<>();
    private OfflinePlayer skull;

    public ItemBuilder(Material material) {
        this.material = material;
    }

    public static ItemBuilder fromSection(ConfigurationSection sec, Material fallback, Map<String, String> ph) {
        Material m = fallback;
        if (sec != null) {
            String matName = sec.getString("material");
            if (matName != null) {
                Material parsed = Material.matchMaterial(matName);
                if (parsed != null && parsed.isItem() && !parsed.isAir()) {
                    m = parsed;
                }
            }
        }
        ItemBuilder b = new ItemBuilder(m);
        if (sec != null) {
            if (sec.contains("name")) {
                b.name(replace(sec.getString("name", ""), ph));
            }
            List<String> l = new ArrayList<>();
            for (String line : sec.getStringList("lore")) {
                l.add(replace(line, ph));
            }
            b.lore(l);
        }
        return b;
    }

    public static String replace(String text, Map<String, String> ph) {
        if (text == null) {
            return "";
        }
        if (ph != null) {
            for (Map.Entry<String, String> e : ph.entrySet()) {
                text = text.replace("{" + e.getKey() + "}", e.getValue() == null ? "" : e.getValue());
            }
        }
        return text;
    }

    public ItemBuilder name(String name) {
        this.name = name;
        return this;
    }

    public ItemBuilder lore(List<String> lore) {
        this.lore = new ArrayList<>(lore);
        return this;
    }

    public ItemBuilder addLore(String line) {
        this.lore.add(line);
        return this;
    }

    public ItemBuilder skull(OfflinePlayer player) {
        this.skull = player;
        return this;
    }

    public ItemStack build() {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return stack;
        }
        if (name != null) {
            meta.displayName(MessageUtils.item(name));
        }
        if (!lore.isEmpty()) {
            List<Component> components = new ArrayList<>();
            for (String line : lore) {
                components.add(MessageUtils.item(line));
            }
            meta.lore(components);
        }
        if (skull != null && meta instanceof SkullMeta skullMeta) {
            skullMeta.setOwningPlayer(skull);
        }
        meta.addItemFlags(ItemFlag.values());
        stack.setItemMeta(meta);
        return stack;
    }
}
