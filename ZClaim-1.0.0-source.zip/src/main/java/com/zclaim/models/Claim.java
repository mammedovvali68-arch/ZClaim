package com.zclaim.models;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class Claim {

    /** Yönetici korumalı (sahipsiz ama claimlenemez) bölgelerin sahibi. */
    public static final UUID SERVER_UUID = new UUID(0L, 0L);
    public static final String SERVER_NAME = "Sunucu";

    public static final class Trust {
        private final UUID uuid;
        private final String name;
        private final int mask;

        public Trust(UUID uuid, String name, int mask) {
            this.uuid = uuid;
            this.name = name;
            this.mask = mask;
        }

        public UUID getUuid() {
            return uuid;
        }

        public String getName() {
            return name;
        }

        public int getMask() {
            return mask;
        }
    }

    private final int id;
    private volatile UUID ownerUuid;
    private volatile String ownerName;
    private final UUID worldUuid;
    private final String worldName;
    private final int chunkX;
    private final int chunkZ;
    private final long createdAt;
    private final Map<UUID, Trust> trusts = new ConcurrentHashMap<>();
    private final ClaimSettings settings;

    public Claim(int id, UUID ownerUuid, String ownerName, UUID worldUuid, String worldName,
                 int chunkX, int chunkZ, long createdAt, ClaimSettings settings) {
        this.id = id;
        this.ownerUuid = ownerUuid;
        this.ownerName = ownerName;
        this.worldUuid = worldUuid;
        this.worldName = worldName;
        this.chunkX = chunkX;
        this.chunkZ = chunkZ;
        this.createdAt = createdAt;
        this.settings = settings;
    }

    public int getId() {
        return id;
    }

    public UUID getOwnerUuid() {
        return ownerUuid;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwner(UUID uuid, String name) {
        this.ownerUuid = uuid;
        this.ownerName = name;
    }

    public UUID getWorldUuid() {
        return worldUuid;
    }

    public String getWorldName() {
        return worldName;
    }

    public int getChunkX() {
        return chunkX;
    }

    public int getChunkZ() {
        return chunkZ;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public ClaimSettings getSettings() {
        return settings;
    }

    public boolean isServerOwned() {
        return SERVER_UUID.equals(ownerUuid);
    }

    public boolean isOwner(UUID uuid) {
        return uuid != null && !isServerOwned() && ownerUuid.equals(uuid);
    }

    public int getTrustMask(UUID uuid) {
        Trust t = trusts.get(uuid);
        return t == null ? 0 : t.getMask();
    }

    public boolean hasPermission(UUID uuid, ClaimPermission permission) {
        return isOwner(uuid) || ClaimPermission.allows(getTrustMask(uuid), permission);
    }

    public void setTrust(UUID uuid, String name, int mask) {
        if (mask == 0) {
            trusts.remove(uuid);
        } else {
            trusts.put(uuid, new Trust(uuid, name, mask));
        }
    }

    public Trust getTrust(UUID uuid) {
        return trusts.get(uuid);
    }

    public Collection<Trust> getTrusts() {
        return Collections.unmodifiableCollection(trusts.values());
    }
}
