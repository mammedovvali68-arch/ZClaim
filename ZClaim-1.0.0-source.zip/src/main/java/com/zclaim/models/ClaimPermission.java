package com.zclaim.models;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Bağımsız izin bitleri. Etkin yetki kontrolü {@link #allows(int, ClaimPermission)} ile yapılır:
 * CONTAINER, BUILD'i; BUILD de ACCESS'i kapsar. MANAGE bağımsızdır (inşa yetkisi vermez).
 */
public enum ClaimPermission {
    BUILD(1),
    CONTAINER(2),
    ACCESS(4),
    MANAGE(8);

    public static final int ALL_BITS = 15;

    private final int bit;

    ClaimPermission(int bit) {
        this.bit = bit;
    }

    public int bit() {
        return bit;
    }

    public static boolean allows(int mask, ClaimPermission required) {
        switch (required) {
            case MANAGE:
                return (mask & MANAGE.bit) != 0;
            case CONTAINER:
                return (mask & CONTAINER.bit) != 0;
            case BUILD:
                return (mask & (BUILD.bit | CONTAINER.bit)) != 0;
            case ACCESS:
                return (mask & (ACCESS.bit | BUILD.bit | CONTAINER.bit)) != 0;
            default:
                return false;
        }
    }

    public static ClaimPermission parse(String text) {
        if (text == null) {
            return null;
        }
        try {
            return valueOf(text.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    public static List<ClaimPermission> fromMask(int mask) {
        List<ClaimPermission> list = new ArrayList<>();
        for (ClaimPermission p : values()) {
            if ((mask & p.bit) != 0) {
                list.add(p);
            }
        }
        return list;
    }
}
