package com.zclaim.models;

import org.bukkit.configuration.file.FileConfiguration;

import java.util.EnumMap;
import java.util.Map;

public final class ClaimSettings {

    public enum Flag {
        PVP("pvp", "pvp", false),
        MOB_SPAWNING("mob_spawning", "mob-spawning", true),
        CREEPER_EXPLOSIONS("creeper_explosions", "creeper-explosions", false),
        TNT_EXPLOSIONS("tnt_explosions", "tnt-explosions", false),
        FIRE_SPREAD("fire_spread", "fire-spread", false),
        FLUID_FLOW("fluid_flow", "fluid-flow", true),
        MOB_GRIEFING("mob_griefing", "mob-griefing", false);

        private final String column;
        private final String configKey;
        private final boolean defaultValue;

        Flag(String column, String configKey, boolean defaultValue) {
            this.column = column;
            this.configKey = configKey;
            this.defaultValue = defaultValue;
        }

        public String column() {
            return column;
        }

        public String configKey() {
            return configKey;
        }

        public boolean defaultValue() {
            return defaultValue;
        }
    }

    private final Map<Flag, Boolean> values = new EnumMap<>(Flag.class);

    public ClaimSettings() {
        for (Flag f : Flag.values()) {
            values.put(f, f.defaultValue());
        }
    }

    public static ClaimSettings defaults(FileConfiguration cfg) {
        ClaimSettings s = new ClaimSettings();
        for (Flag f : Flag.values()) {
            s.values.put(f, cfg.getBoolean("default-settings." + f.configKey(), f.defaultValue()));
        }
        return s;
    }

    public synchronized boolean get(Flag flag) {
        return values.get(flag);
    }

    public synchronized void set(Flag flag, boolean value) {
        values.put(flag, value);
    }
}
