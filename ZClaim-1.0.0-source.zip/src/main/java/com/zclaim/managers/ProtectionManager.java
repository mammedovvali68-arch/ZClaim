package com.zclaim.managers;

import com.zclaim.ZClaim;
import com.zclaim.models.Claim;
import com.zclaim.models.ClaimPermission;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ProtectionManager {

    private static final long DENY_COOLDOWN_MS = 1500L;

    private final ZClaim plugin;
    private final Set<UUID> bypass = ConcurrentHashMap.newKeySet();
    private final Map<UUID, Long> lastDeny = new ConcurrentHashMap<>();

    public volatile boolean blockBreak = true;
    public volatile boolean blockPlace = true;
    public volatile boolean containers = true;
    public volatile boolean interactions = true;
    public volatile boolean explosions = true;
    public volatile boolean fireSpread = true;
    public volatile boolean pistons = true;
    public volatile boolean entityDamage = true;

    public ProtectionManager(ZClaim plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        FileConfiguration c = plugin.getConfig();
        blockBreak = c.getBoolean("protection.block-break", true);
        blockPlace = c.getBoolean("protection.block-place", true);
        containers = c.getBoolean("protection.containers", true);
        interactions = c.getBoolean("protection.interactions", true);
        explosions = c.getBoolean("protection.explosions", true);
        fireSpread = c.getBoolean("protection.fire-spread", true);
        pistons = c.getBoolean("protection.pistons", true);
        entityDamage = c.getBoolean("protection.entity-damage", true);
    }

    /** @return bypass'ın yeni durumu */
    public boolean toggleBypass(Player p) {
        UUID u = p.getUniqueId();
        if (bypass.remove(u)) {
            return false;
        }
        bypass.add(u);
        return true;
    }

    public boolean isBypassing(Player p) {
        return bypass.contains(p.getUniqueId()) && p.hasPermission("zclaim.bypass");
    }

    public void forget(UUID uuid) {
        bypass.remove(uuid);
        lastDeny.remove(uuid);
    }

    public boolean canAct(Player p, Claim claim, ClaimPermission perm) {
        if (claim == null) {
            return true;
        }
        if (isBypassing(p)) {
            return true;
        }
        return claim.hasPermission(p.getUniqueId(), perm);
    }

    /** İzin yoksa oyuncuya (aralıklı) bildirir ve false döner. */
    public boolean check(Player p, Claim claim, ClaimPermission perm) {
        if (canAct(p, claim, perm)) {
            return true;
        }
        deny(p, claim);
        return false;
    }

    public boolean check(Player p, Location loc, ClaimPermission perm) {
        return check(p, plugin.claims().getClaimAt(loc), perm);
    }

    public boolean check(Player p, Block block, ClaimPermission perm) {
        return check(p, plugin.claims().getClaimAt(block), perm);
    }

    public void deny(Player p, Claim claim) {
        long now = System.currentTimeMillis();
        Long last = lastDeny.get(p.getUniqueId());
        if (last != null && now - last < DENY_COOLDOWN_MS) {
            return;
        }
        lastDeny.put(p.getUniqueId(), now);
        plugin.messages().send(p, "protection.denied", "owner", claim.getOwnerName());
        plugin.debug("Engellendi: " + p.getName() + " claim #" + claim.getId());
    }
}
