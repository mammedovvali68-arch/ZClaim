package com.zclaim.managers;

import com.zclaim.ZClaim;
import com.zclaim.models.Claim;
import com.zclaim.models.ClaimPermission;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;

public final class TrustManager {

    private final ZClaim plugin;

    public TrustManager(ZClaim plugin) {
        this.plugin = plugin;
    }

    public int defaultMask() {
        ClaimPermission p = ClaimPermission.parse(plugin.getConfig().getString("trust.default-level", "CONTAINER"));
        return (p == null ? ClaimPermission.CONTAINER : p).bit();
    }

    public String levelName(ClaimPermission p) {
        return plugin.messages().get("trust.level-names." + p.name());
    }

    public String describe(int mask) {
        List<String> names = new ArrayList<>();
        for (ClaimPermission p : ClaimPermission.fromMask(mask)) {
            names.add(levelName(p));
        }
        return names.isEmpty() ? "-" : String.join(", ", names);
    }

    public void grant(Claim claim, UUID target, String name, int addMask, Runnable done) {
        int old = claim.getTrustMask(target);
        apply(claim, target, name, old, old | addMask, done);
    }

    public void revoke(Claim claim, UUID target, int removeMask, Runnable done) {
        Claim.Trust existing = claim.getTrust(target);
        if (existing == null) {
            if (done != null) {
                done.run();
            }
            return;
        }
        int old = existing.getMask();
        apply(claim, target, existing.getName(), old, old & ~removeMask, done);
    }

    /** Bellek önce güncellenir (koruma anında etkin), kayıt sırayla DB thread'inde yapılır; hata olursa geri alınır. */
    private void apply(Claim claim, UUID target, String name, int oldMask, int newMask, Runnable done) {
        claim.setTrust(target, name, newMask);
        final int id = claim.getId();
        plugin.database().run(s -> {
            if (newMask == 0) {
                s.deleteTrust(id, target);
            } else {
                s.saveTrust(id, target, name, newMask);
            }
        }).whenComplete((r, ex) -> {
            if (ex != null) {
                plugin.runSync(() -> {
                    claim.setTrust(target, name, oldMask);
                    plugin.getLogger().log(Level.SEVERE, "Trust kaydı başarısız (claim #" + id + ")", ex);
                });
            }
        });
        if (done != null) {
            done.run();
        }
    }
}
