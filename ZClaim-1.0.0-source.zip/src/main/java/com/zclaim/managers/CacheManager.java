package com.zclaim.managers;

import com.zclaim.models.Claim;
import com.zclaim.utils.ChunkUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tüm claimler bellekte tutulur: dünya UUID + chunk(X,Z) anahtarı ile O(1) erişim.
 * Değişiklikler yalnızca ana thread'den yapılır; okumalar her thread'den güvenlidir.
 */
public final class CacheManager {

    private final Map<UUID, Map<Long, Claim>> byChunk = new ConcurrentHashMap<>();
    private final Map<Integer, Claim> byId = new ConcurrentHashMap<>();
    private final Map<UUID, Set<Claim>> byOwner = new ConcurrentHashMap<>();

    public void put(Claim claim) {
        byChunk.computeIfAbsent(claim.getWorldUuid(), k -> new ConcurrentHashMap<>())
                .put(ChunkUtils.key(claim.getChunkX(), claim.getChunkZ()), claim);
        byId.put(claim.getId(), claim);
        byOwner.computeIfAbsent(claim.getOwnerUuid(), k -> ConcurrentHashMap.newKeySet()).add(claim);
    }

    public void remove(Claim claim) {
        Map<Long, Claim> world = byChunk.get(claim.getWorldUuid());
        if (world != null) {
            world.remove(ChunkUtils.key(claim.getChunkX(), claim.getChunkZ()), claim);
        }
        byId.remove(claim.getId());
        Set<Claim> owned = byOwner.get(claim.getOwnerUuid());
        if (owned != null) {
            owned.remove(claim);
            if (owned.isEmpty()) {
                byOwner.remove(claim.getOwnerUuid());
            }
        }
    }

    public void changeOwner(Claim claim, UUID newOwner, String newName) {
        Set<Claim> old = byOwner.get(claim.getOwnerUuid());
        if (old != null) {
            old.remove(claim);
            if (old.isEmpty()) {
                byOwner.remove(claim.getOwnerUuid());
            }
        }
        claim.setOwner(newOwner, newName);
        byOwner.computeIfAbsent(newOwner, k -> ConcurrentHashMap.newKeySet()).add(claim);
    }

    public Claim get(UUID world, int chunkX, int chunkZ) {
        Map<Long, Claim> map = byChunk.get(world);
        return map == null ? null : map.get(ChunkUtils.key(chunkX, chunkZ));
    }

    public Claim getById(int id) {
        return byId.get(id);
    }

    public int countByOwner(UUID owner) {
        Set<Claim> set = byOwner.get(owner);
        return set == null ? 0 : set.size();
    }

    public List<Claim> getByOwner(UUID owner) {
        Set<Claim> set = byOwner.get(owner);
        List<Claim> list = set == null ? new ArrayList<>() : new ArrayList<>(set);
        list.sort(Comparator.comparingInt(Claim::getId));
        return list;
    }

    public List<Claim> all() {
        List<Claim> list = new ArrayList<>(byId.values());
        list.sort(Comparator.comparingInt(Claim::getId));
        return list;
    }

    public Collection<Claim> raw() {
        return byId.values();
    }

    public boolean isEmpty() {
        return byId.isEmpty();
    }

    public int size() {
        return byId.size();
    }
}
