package com.zclaim.managers;

import com.zclaim.ZClaim;
import com.zclaim.models.Claim;
import com.zclaim.models.ClaimPermission;
import com.zclaim.models.ClaimSettings;
import com.zclaim.utils.MessageUtils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachmentInfo;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.logging.Level;

/**
 * Claim yaşam döngüsü. Tüm durum değişiklikleri ana thread'de yapılır, veritabanı yazmaları
 * ayrı bir thread'de çalışır. Claim oluşturma: ücret tahsil -> DB kaydı -> (hata olursa) iade.
 */
public final class ClaimManager {

    private static final String LIMIT_PREFIX = "zclaim.limit.";
    private static final long CONFIRM_MILLIS = 30_000L;

    private record Pending(boolean transfer, int claimId, UUID target, String targetName, long expires) {
    }

    private final ZClaim plugin;
    private final CacheManager cache;
    /** Şu an claim işlemi süren oyuncular (çift ücret önleme). Yalnızca ana thread. */
    private final Set<UUID> busy = new HashSet<>();
    /** Veritabanına yazılmakta olan chunk anahtarları (aynı anda iki claim önleme). Yalnızca ana thread. */
    private final Set<String> pendingKeys = new HashSet<>();
    private final Map<UUID, Pending> pending = new HashMap<>();

    public ClaimManager(ZClaim plugin, CacheManager cache) {
        this.plugin = plugin;
        this.cache = cache;
    }

    public void loadAll() throws SQLException {
        for (Claim c : plugin.database().storage().loadAll()) {
            cache.put(c);
        }
    }

    // ---------------------------------------------------------------- sorgular

    public Claim getClaimAt(Location loc) {
        if (loc == null || cache.isEmpty()) {
            return null;
        }
        World w = loc.getWorld();
        if (w == null) {
            return null;
        }
        return cache.get(w.getUID(), loc.getBlockX() >> 4, loc.getBlockZ() >> 4);
    }

    public Claim getClaimAt(Block block) {
        if (cache.isEmpty()) {
            return null;
        }
        return cache.get(block.getWorld().getUID(), block.getX() >> 4, block.getZ() >> 4);
    }

    public Claim getClaimAt(World world, int chunkX, int chunkZ) {
        return cache.get(world.getUID(), chunkX, chunkZ);
    }

    public boolean isEmpty() {
        return cache.isEmpty();
    }

    public boolean isWorldAllowed(World world) {
        List<String> worlds = plugin.getConfig().getStringList("claim.worlds");
        if (worlds.isEmpty()) {
            return true;
        }
        for (String name : worlds) {
            if (name.equalsIgnoreCase(world.getName())) {
                return true;
            }
        }
        return false;
    }

    public boolean isUnlimited(Player p) {
        return plugin.getConfig().getBoolean("limits.allow-admin-bypass", true) && p.hasPermission("zclaim.admin");
    }

    /** default-max-claims ile zclaim.limit.<n> yetkilerinden en büyüğü (LuckPerms grupları için hazır). */
    public int getMaxClaims(Player p) {
        int max = plugin.getConfig().getInt("limits.default-max-claims", 10);
        for (PermissionAttachmentInfo info : p.getEffectivePermissions()) {
            String perm = info.getPermission();
            if (info.getValue() && perm.startsWith(LIMIT_PREFIX)) {
                try {
                    max = Math.max(max, Integer.parseInt(perm.substring(LIMIT_PREFIX.length())));
                } catch (NumberFormatException ignored) {
                    // geçersiz yetki düğümü
                }
            }
        }
        if (!plugin.getConfig().getBoolean("claim.allow-multiple-claims", true)) {
            max = Math.min(max, 1);
        }
        return max;
    }

    public boolean canManage(Player p, Claim c) {
        return c.hasPermission(p.getUniqueId(), ClaimPermission.MANAGE);
    }

    public String[] placeholders(Claim c) {
        return new String[]{
                "id", String.valueOf(c.getId()),
                "owner", c.getOwnerName(),
                "uuid", c.getOwnerUuid().toString(),
                "world", c.getWorldName(),
                "worldUuid", c.getWorldUuid().toString(),
                "x", String.valueOf(c.getChunkX()),
                "z", String.valueOf(c.getChunkZ()),
                "date", MessageUtils.date(c.getCreatedAt()),
                "trusted", String.valueOf(c.getTrusts().size())
        };
    }

    public void sendInfo(CommandSender to, Claim c) {
        plugin.messages().sendLines(to, "info.lines", placeholders(c));
    }

    // ---------------------------------------------------------------- oluşturma

    public void createClaim(Player p) {
        MessageUtils m = plugin.messages();
        FileConfiguration cfg = plugin.getConfig();
        UUID uuid = p.getUniqueId();
        Location loc = p.getLocation();
        World world = loc.getWorld();
        int cx = loc.getBlockX() >> 4;
        int cz = loc.getBlockZ() >> 4;

        if (!isWorldAllowed(world)) {
            m.send(p, "claim.world-disabled");
            return;
        }
        if (busy.contains(uuid)) {
            m.send(p, "claim.busy");
            return;
        }
        Claim existing = cache.get(world.getUID(), cx, cz);
        if (existing != null) {
            if (existing.isOwner(uuid)) {
                m.send(p, "claim.already-yours");
            } else if (existing.isServerOwned()) {
                m.send(p, "claim.server-claimed");
            } else {
                m.send(p, "claim.already-claimed", "owner", existing.getOwnerName());
            }
            return;
        }
        String key = pendingKey(world.getUID(), cx, cz);
        if (pendingKeys.contains(key)) {
            m.send(p, "claim.chunk-busy");
            return;
        }
        if (!isUnlimited(p)) {
            int max = getMaxClaims(p);
            if (cache.countByOwner(uuid) >= max) {
                m.send(p, "claim.limit-reached", "max", String.valueOf(max));
                return;
            }
        }

        EconomyManager eco = plugin.economy();
        if (eco.isRequired() && !eco.isAvailable()) {
            m.send(p, "claim.economy-unavailable");
            return;
        }
        final double price = eco.price();
        final boolean charge = eco.isRequired() && price > 0;
        if (charge && !eco.has(p, price)) {
            m.send(p, "claim.insufficient", "price", eco.formatPrice(price));
            return;
        }

        busy.add(uuid);
        pendingKeys.add(key);
        if (charge && !eco.withdraw(p, price)) {
            busy.remove(uuid);
            pendingKeys.remove(key);
            m.send(p, "claim.economy-failed");
            return;
        }

        final String ownerName = p.getName();
        final UUID worldUuid = world.getUID();
        final String worldName = world.getName();
        final long now = System.currentTimeMillis();
        final ClaimSettings settings = ClaimSettings.defaults(cfg);

        plugin.database()
                .supply(s -> s.insertClaim(uuid, ownerName, worldUuid, worldName, cx, cz, now, settings))
                .whenComplete((id, ex) -> plugin.runSync(() -> {
                    busy.remove(uuid);
                    pendingKeys.remove(key);
                    Player online = Bukkit.getPlayer(uuid);

                    if (ex != null || id == null) {
                        plugin.getLogger().log(Level.SEVERE, "Claim kaydı başarısız (" + ownerName + ", "
                                + worldName + " " + cx + "," + cz + ")", ex);
                        boolean refunded = !charge;
                        if (charge) {
                            refunded = plugin.economy().deposit(Bukkit.getOfflinePlayer(uuid), price);
                            if (!refunded) {
                                plugin.getLogger().severe("İADE BAŞARISIZ! Oyuncu: " + ownerName + " (" + uuid
                                        + ") Tutar: " + price + " - elle iade edin.");
                            }
                        }
                        if (online != null) {
                            if (charge && !refunded) {
                                m.send(online, "claim.refund-failed");
                            } else {
                                m.send(online, charge ? "claim.db-error" : "claim.db-error-free");
                            }
                        }
                        return;
                    }

                    Claim claim = new Claim(id, uuid, ownerName, worldUuid, worldName, cx, cz, now, settings);
                    cache.put(claim);
                    plugin.debug("Claim oluşturuldu #" + id + " " + ownerName + " " + worldName + " " + cx + "," + cz);
                    if (online != null) {
                        m.send(online, "claim.created");
                        if (charge) {
                            m.send(online, "claim.charged", "price", plugin.economy().formatPrice(price));
                        }
                        m.title(online, "claim-created");
                    }
                }));
    }

    /** Yönetici: bulunulan chunkı sunucu korumasına alır (kimse claimleyemez). */
    public void createServerClaim(Player admin) {
        MessageUtils m = plugin.messages();
        Location loc = admin.getLocation();
        World world = loc.getWorld();
        int cx = loc.getBlockX() >> 4;
        int cz = loc.getBlockZ() >> 4;
        Claim existing = cache.get(world.getUID(), cx, cz);
        if (existing != null) {
            m.send(admin, "claim.already-claimed", "owner", existing.getOwnerName());
            return;
        }
        String key = pendingKey(world.getUID(), cx, cz);
        if (!pendingKeys.add(key)) {
            m.send(admin, "claim.chunk-busy");
            return;
        }
        final UUID worldUuid = world.getUID();
        final String worldName = world.getName();
        final long now = System.currentTimeMillis();
        final ClaimSettings settings = ClaimSettings.defaults(plugin.getConfig());
        plugin.database()
                .supply(s -> s.insertClaim(Claim.SERVER_UUID, Claim.SERVER_NAME, worldUuid, worldName, cx, cz, now, settings))
                .whenComplete((id, ex) -> plugin.runSync(() -> {
                    pendingKeys.remove(key);
                    if (ex != null || id == null) {
                        plugin.getLogger().log(Level.SEVERE, "Sunucu claimi kaydedilemedi", ex);
                        m.send(admin, "admin.protect-failed");
                        return;
                    }
                    Claim claim = new Claim(id, Claim.SERVER_UUID, Claim.SERVER_NAME, worldUuid, worldName, cx, cz, now, settings);
                    cache.put(claim);
                    m.send(admin, "admin.protected", "id", String.valueOf(id));
                    logAdmin(admin, "PROTECT", id, worldName + " " + cx + "," + cz);
                }));
    }

    private static String pendingKey(UUID world, int cx, int cz) {
        return world + ":" + cx + ":" + cz;
    }

    // ---------------------------------------------------------------- silme / devir / ayar

    public void deleteClaim(Claim claim, Consumer<Boolean> callback) {
        plugin.database().run(s -> s.deleteClaim(claim.getId())).whenComplete((r, ex) -> plugin.runSync(() -> {
            if (ex != null) {
                plugin.getLogger().log(Level.SEVERE, "Claim silinemedi #" + claim.getId(), ex);
                callback.accept(false);
                return;
            }
            cache.remove(claim);
            callback.accept(true);
        }));
    }

    public void setFlag(Claim claim, ClaimSettings.Flag flag, boolean value, Runnable done) {
        final boolean old = claim.getSettings().get(flag);
        claim.getSettings().set(flag, value);
        plugin.database().run(s -> s.updateFlag(claim.getId(), flag, value)).whenComplete((r, ex) -> {
            if (ex != null) {
                plugin.runSync(() -> {
                    claim.getSettings().set(flag, old);
                    plugin.getLogger().log(Level.SEVERE, "Claim ayarı kaydedilemedi #" + claim.getId(), ex);
                });
            }
        });
        if (done != null) {
            done.run();
        }
    }

    public void logAdmin(CommandSender sender, String action, Integer claimId, String details) {
        final String name = sender.getName();
        final UUID uuid = sender instanceof Player pl ? pl.getUniqueId() : null;
        final long now = System.currentTimeMillis();
        plugin.getLogger().info("[ADMIN] " + name + " | " + action + " | claim=" + claimId + " | "
                + MessageUtils.date(now) + (details == null ? "" : " | " + details));
        plugin.database().run(s -> s.logAdmin(uuid, name, action, claimId, details, now)).exceptionally(ex -> {
            plugin.getLogger().log(Level.WARNING, "Admin logu yazılamadı", ex);
            return null;
        });
    }

    // ---------------------------------------------------------------- onaylı işlemler (abandon / transfer)

    private Component buttons(String path, String yesCmd, String noCmd) {
        MessageUtils m = plugin.messages();
        Component yes = MessageUtils.color(m.raw(path + ".yes"))
                .clickEvent(ClickEvent.runCommand(yesCmd))
                .hoverEvent(HoverEvent.showText(MessageUtils.color(m.raw(path + ".yes-hover"))));
        Component no = MessageUtils.color(m.raw(path + ".no"))
                .clickEvent(ClickEvent.runCommand(noCmd))
                .hoverEvent(HoverEvent.showText(MessageUtils.color(m.raw(path + ".no-hover"))));
        return yes.append(Component.space()).append(no);
    }

    private Pending takePending(Player p, boolean transfer) {
        Pending pd = pending.get(p.getUniqueId());
        if (pd == null || pd.transfer() != transfer) {
            return null;
        }
        pending.remove(p.getUniqueId());
        if (System.currentTimeMillis() > pd.expires()) {
            return null;
        }
        return pd;
    }

    public void promptAbandon(Player p, Claim c) {
        MessageUtils m = plugin.messages();
        if (!c.isOwner(p.getUniqueId())) {
            m.send(p, "general.not-owner");
            return;
        }
        pending.put(p.getUniqueId(), new Pending(false, c.getId(), null, null, System.currentTimeMillis() + CONFIRM_MILLIS));
        m.send(p, "abandon.question", "id", String.valueOf(c.getId()));
        p.sendMessage(buttons("abandon", "/claim abandon confirm", "/claim abandon cancel"));
    }

    public void confirmAbandon(Player p) {
        MessageUtils m = plugin.messages();
        Pending pd = takePending(p, false);
        if (pd == null) {
            m.send(p, "abandon.expired");
            return;
        }
        Claim c = cache.getById(pd.claimId());
        if (c == null) {
            m.send(p, "general.claim-not-found");
            return;
        }
        if (!c.isOwner(p.getUniqueId())) {
            m.send(p, "general.not-owner");
            return;
        }
        deleteClaim(c, ok -> {
            if (!ok) {
                m.send(p, "abandon.failed");
                return;
            }
            m.send(p, "abandon.done");
            refundOnAbandon(p);
        });
    }

    private void refundOnAbandon(Player p) {
        FileConfiguration cfg = plugin.getConfig();
        if (!cfg.getBoolean("economy.refund-on-abandon", false)) {
            return;
        }
        EconomyManager eco = plugin.economy();
        if (!eco.isRequired()) {
            return;
        }
        double amount = eco.price() * cfg.getDouble("economy.refund-percent", 100D) / 100D;
        if (amount <= 0) {
            return;
        }
        if (eco.deposit(p, amount)) {
            plugin.messages().send(p, "abandon.refunded", "amount", eco.formatPrice(amount));
        } else {
            plugin.messages().send(p, "claim.refund-failed");
        }
    }

    public void cancelPending(Player p, boolean transfer) {
        Pending pd = pending.get(p.getUniqueId());
        if (pd != null && pd.transfer() == transfer) {
            pending.remove(p.getUniqueId());
            plugin.messages().send(p, transfer ? "transfer.cancelled" : "abandon.cancelled");
        } else {
            plugin.messages().send(p, transfer ? "transfer.expired" : "abandon.expired");
        }
    }

    public void promptTransfer(Player p, Claim c, Player target) {
        MessageUtils m = plugin.messages();
        if (!c.isOwner(p.getUniqueId())) {
            m.send(p, "general.not-owner");
            return;
        }
        if (target.getUniqueId().equals(p.getUniqueId())) {
            m.send(p, "transfer.self");
            return;
        }
        pending.put(p.getUniqueId(), new Pending(true, c.getId(), target.getUniqueId(), target.getName(),
                System.currentTimeMillis() + CONFIRM_MILLIS));
        m.send(p, "transfer.question", "id", String.valueOf(c.getId()), "player", target.getName());
        p.sendMessage(buttons("transfer", "/claim transfer confirm", "/claim transfer cancel"));
    }

    public void confirmTransfer(Player p) {
        MessageUtils m = plugin.messages();
        Pending pd = takePending(p, true);
        if (pd == null) {
            m.send(p, "transfer.expired");
            return;
        }
        Claim c = cache.getById(pd.claimId());
        if (c == null) {
            m.send(p, "general.claim-not-found");
            return;
        }
        if (!c.isOwner(p.getUniqueId())) {
            m.send(p, "general.not-owner");
            return;
        }
        Player target = Bukkit.getPlayer(pd.target());
        if (target == null) {
            m.send(p, "transfer.target-offline");
            return;
        }
        if (!isUnlimited(target) && cache.countByOwner(target.getUniqueId()) >= getMaxClaims(target)) {
            m.send(p, "transfer.target-limit", "player", target.getName());
            return;
        }
        final UUID newUuid = target.getUniqueId();
        final String newName = target.getName();
        plugin.database().run(s -> s.transferOwner(c.getId(), newUuid, newName)).whenComplete((r, ex) -> plugin.runSync(() -> {
            if (ex != null) {
                plugin.getLogger().log(Level.SEVERE, "Claim devri başarısız #" + c.getId(), ex);
                m.send(p, "transfer.failed");
                return;
            }
            if (cache.getById(c.getId()) != c) {
                return; // bu sırada claim silinmiş
            }
            c.setTrust(newUuid, newName, 0);
            cache.changeOwner(c, newUuid, newName);
            m.send(p, "transfer.done", "player", newName);
            Player t = Bukkit.getPlayer(newUuid);
            if (t != null) {
                m.send(t, "transfer.received", "owner", p.getName(), "id", String.valueOf(c.getId()));
            }
        }));
    }

    public void forget(UUID uuid) {
        pending.remove(uuid);
    }

    public CacheManager cache() {
        return cache;
    }
}
