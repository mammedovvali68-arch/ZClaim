package com.zclaim.managers;

import com.zclaim.ZClaim;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.Locale;
import java.util.logging.Level;

public final class EconomyManager {

    private final ZClaim plugin;
    private Economy economy;

    public EconomyManager(ZClaim plugin) {
        this.plugin = plugin;
    }

    /** economy.enabled=false ise claimler bilerek ücretsizdir. */
    public boolean isRequired() {
        return plugin.getConfig().getBoolean("economy.enabled", true);
    }

    public double price() {
        return Math.max(0D, plugin.getConfig().getDouble("economy.claim-price", 200D));
    }

    /** Ekonomi sağlayıcıları Vault'tan sonra kaydolabilir; bu yüzden gerektiğinde tekrar aranır. */
    private Economy provider() {
        if (economy != null) {
            return economy;
        }
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) {
            return null;
        }
        RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
        if (rsp != null) {
            economy = rsp.getProvider();
        }
        return economy;
    }

    public void refresh() {
        economy = null;
    }

    public boolean isAvailable() {
        return !isRequired() || provider() != null;
    }

    public boolean has(OfflinePlayer player, double amount) {
        Economy e = provider();
        return e != null && e.has(player, amount);
    }

    public boolean withdraw(OfflinePlayer player, double amount) {
        Economy e = provider();
        if (e == null) {
            return false;
        }
        try {
            return e.withdrawPlayer(player, amount).transactionSuccess();
        } catch (RuntimeException ex) {
            plugin.getLogger().log(Level.SEVERE, "Ekonomi tahsilatı sırasında hata", ex);
            return false;
        }
    }

    public boolean deposit(OfflinePlayer player, double amount) {
        Economy e = provider();
        if (e == null) {
            return false;
        }
        try {
            return e.depositPlayer(player, amount).transactionSuccess();
        } catch (RuntimeException ex) {
            plugin.getLogger().log(Level.SEVERE, "Ekonomi iadesi sırasında hata", ex);
            return false;
        }
    }

    public String formatPrice(double amount) {
        if (amount == Math.rint(amount)) {
            return String.valueOf((long) amount);
        }
        return String.format(Locale.US, "%.2f", amount);
    }

    public void checkAndWarn() {
        if (!isRequired()) {
            plugin.getLogger().info("economy.enabled=false: claimler ücretsiz oluşturulacak.");
            return;
        }
        Economy e = provider();
        if (e == null) {
            plugin.getLogger().warning("==============================================================");
            plugin.getLogger().warning("Vault veya bir ekonomi sağlayıcısı (örn. EssentialsX) bulunamadı!");
            plugin.getLogger().warning("Ekonomi gerektiren işlemler (claim oluşturma) DEVRE DIŞI.");
            plugin.getLogger().warning("Ücretsiz claim için config.yml içinde economy.enabled: false yapın.");
            plugin.getLogger().warning("==============================================================");
        } else {
            plugin.getLogger().info("Vault ekonomi sağlayıcısı bağlandı: " + e.getName());
        }
    }
}
