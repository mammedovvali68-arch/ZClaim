package com.zclaim.managers;

import com.zclaim.ZClaim;
import com.zclaim.models.Claim;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Claim sınırlarını (chunk çerçevesi) geçici parçacıklarla yalnızca isteyen oyuncuya gösterir. */
public final class BorderManager {

    private final ZClaim plugin;
    private final Map<UUID, BukkitTask> tasks = new HashMap<>();

    public BorderManager(ZClaim plugin) {
        this.plugin = plugin;
    }

    public boolean isEnabled() {
        return plugin.getConfig().getBoolean("particles.enabled", true);
    }

    public void stop(UUID uuid) {
        BukkitTask t = tasks.remove(uuid);
        if (t != null) {
            t.cancel();
        }
    }

    public void stopAll() {
        for (BukkitTask t : tasks.values()) {
            t.cancel();
        }
        tasks.clear();
    }

    private Particle resolve(String name, Particle fallback) {
        if (name == null) {
            return fallback;
        }
        String n = name.trim().toUpperCase(Locale.ROOT);
        if (n.equals("VILLAGER_HAPPY")) {
            n = "HAPPY_VILLAGER"; // 1.20.5+ adı
        }
        try {
            Particle p = Particle.valueOf(n);
            if (p.getDataType() != Void.class) {
                plugin.getLogger().warning("Particle '" + name + "' ek veri gerektiriyor, kullanılamaz. Varsayılan kullanılıyor.");
                return fallback;
            }
            return p;
        } catch (IllegalArgumentException ex) {
            plugin.getLogger().warning("Geçersiz particle adı: '" + name + "'. Varsayılan kullanılıyor.");
            return fallback;
        }
    }

    public void show(Player player, Claim claim, boolean own) {
        stop(player.getUniqueId());
        World world = Bukkit.getWorld(claim.getWorldUuid());
        if (world == null || !player.getWorld().getUID().equals(claim.getWorldUuid())) {
            return;
        }
        FileConfiguration cfg = plugin.getConfig();
        final Particle particle = own
                ? resolve(cfg.getString("particles.type", "HAPPY_VILLAGER"), Particle.HAPPY_VILLAGER)
                : resolve(cfg.getString("particles.other-type", "FLAME"), Particle.FLAME);
        final long period = Math.max(2L, cfg.getLong("particles.interval-ticks", 10L));
        final int maxRuns = (int) Math.max(1L, (cfg.getLong("particles.duration-seconds", 5L) * 20L) / period);
        final double spacing = Math.max(0.5D, cfg.getDouble("particles.spacing", 1.0D));
        final double minX = claim.getChunkX() * 16.0D;
        final double minZ = claim.getChunkZ() * 16.0D;
        final double maxX = minX + 16.0D;
        final double maxZ = minZ + 16.0D;
        final UUID uuid = player.getUniqueId();
        final UUID worldUuid = claim.getWorldUuid();

        BukkitTask task = new BukkitRunnable() {
            private int runs = 0;

            @Override
            public void run() {
                if (!player.isOnline() || !player.getWorld().getUID().equals(worldUuid) || runs++ >= maxRuns) {
                    cancel();
                    tasks.remove(uuid);
                    return;
                }
                double y = player.getLocation().getY();
                double lowY = y + 0.5D;
                double highY = y + 1.5D;
                for (double d = 0; d <= 16.0D; d += spacing) {
                    line(minX + d, lowY, minZ);
                    line(minX + d, lowY, maxZ);
                    line(minX, lowY, minZ + d);
                    line(maxX, lowY, minZ + d);
                    line(minX + d, highY, minZ);
                    line(minX + d, highY, maxZ);
                    line(minX, highY, minZ + d);
                    line(maxX, highY, minZ + d);
                }
                for (double h = -3.0D; h <= 5.0D; h += spacing) {
                    line(minX, y + h, minZ);
                    line(maxX, y + h, minZ);
                    line(minX, y + h, maxZ);
                    line(maxX, y + h, maxZ);
                }
            }

            private void line(double x, double y, double z) {
                player.spawnParticle(particle, x, y, z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            }
        }.runTaskTimer(plugin, 0L, period);
        tasks.put(uuid, task);
    }
}
