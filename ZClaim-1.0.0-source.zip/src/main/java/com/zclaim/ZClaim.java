package com.zclaim;

import com.zclaim.commands.ClaimAdminCommand;
import com.zclaim.commands.ClaimCommand;
import com.zclaim.database.DatabaseManager;
import com.zclaim.gui.GUIManager;
import com.zclaim.listeners.GUIListener;
import com.zclaim.listeners.PlayerMoveListener;
import com.zclaim.listeners.ProtectionListener;
import com.zclaim.managers.BorderManager;
import com.zclaim.managers.CacheManager;
import com.zclaim.managers.ClaimManager;
import com.zclaim.managers.EconomyManager;
import com.zclaim.managers.ProtectionManager;
import com.zclaim.managers.TrustManager;
import com.zclaim.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.logging.Level;

public final class ZClaim extends JavaPlugin {

    private MessageUtils messages;
    private DatabaseManager database;
    private CacheManager cache;
    private ClaimManager claims;
    private EconomyManager economy;
    private TrustManager trust;
    private ProtectionManager protection;
    private BorderManager borders;
    private GUIManager gui;
    private boolean debug;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.messages = new MessageUtils(this);
        this.debug = getConfig().getBoolean("debug", false);

        this.database = new DatabaseManager(this);
        try {
            database.init();
        } catch (Exception ex) {
            getLogger().log(Level.SEVERE, "Veritabanı başlatılamadı, eklenti devre dışı bırakılıyor.", ex);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        this.cache = new CacheManager();
        this.economy = new EconomyManager(this);
        this.claims = new ClaimManager(this, cache);
        try {
            claims.loadAll();
        } catch (Exception ex) {
            getLogger().log(Level.SEVERE, "Claimler yüklenemedi, eklenti devre dışı bırakılıyor.", ex);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        this.trust = new TrustManager(this);
        this.protection = new ProtectionManager(this);
        this.borders = new BorderManager(this);
        this.gui = new GUIManager(this);

        ClaimCommand claimCommand = new ClaimCommand(this);
        PluginCommand claimCmd = getCommand("claim");
        if (claimCmd != null) {
            claimCmd.setExecutor(claimCommand);
            claimCmd.setTabCompleter(claimCommand);
        }
        ClaimAdminCommand adminCommand = new ClaimAdminCommand(this);
        PluginCommand adminCmd = getCommand("claimadmin");
        if (adminCmd != null) {
            adminCmd.setExecutor(adminCommand);
            adminCmd.setTabCompleter(adminCommand);
        }

        PlayerMoveListener moveListener = new PlayerMoveListener(this);
        getServer().getPluginManager().registerEvents(new ProtectionListener(this), this);
        getServer().getPluginManager().registerEvents(moveListener, this);
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);
        moveListener.initOnlinePlayers();

        // Ekonomi sağlayıcıları tüm eklentiler yüklendikten sonra kontrol edilir.
        Bukkit.getScheduler().runTask(this, () -> economy.checkAndWarn());
        getLogger().info(cache.size() + " claim yüklendi. ZClaim " + getDescription().getVersion() + " hazır.");
    }

    @Override
    public void onDisable() {
        if (borders != null) {
            borders.stopAll();
        }
        if (database != null) {
            database.shutdown();
        }
    }

    public void reloadAll() {
        reloadConfig();
        debug = getConfig().getBoolean("debug", false);
        protection.reload();
        economy.refresh();
        economy.checkAndWarn();
    }

    /** Ana thread'de çalıştırır (zaten ana thread ise doğrudan). */
    public void runSync(Runnable task) {
        if (Bukkit.isPrimaryThread()) {
            task.run();
        } else if (isEnabled()) {
            Bukkit.getScheduler().runTask(this, task);
        } else {
            getLogger().warning("Eklenti kapalıyken bir geri çağrı atlandı.");
        }
    }

    public void debug(String message) {
        if (debug) {
            getLogger().info("[DEBUG] " + message);
        }
    }

    public MessageUtils messages() {
        return messages;
    }

    public DatabaseManager database() {
        return database;
    }

    public CacheManager cache() {
        return cache;
    }

    public ClaimManager claims() {
        return claims;
    }

    public EconomyManager economy() {
        return economy;
    }

    public TrustManager trust() {
        return trust;
    }

    public ProtectionManager protection() {
        return protection;
    }

    public BorderManager borders() {
        return borders;
    }

    public GUIManager gui() {
        return gui;
    }
}
