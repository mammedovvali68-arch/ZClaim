package com.zclaim.gui;

import com.zclaim.ZClaim;
import com.zclaim.models.Claim;
import com.zclaim.utils.ItemBuilder;
import com.zclaim.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** İzinli oyuncu listesi / oyuncu ekleme / devir için oyuncu seçici. */
public final class TrustGUI extends ZGui {

    public enum Mode { TRUSTED, ADD, TRANSFER }

    private static final int PER_PAGE = 45;
    private static final int PREVIOUS = 45;
    private static final int ADD_BUTTON = 47;
    private static final int BACK = 48;
    private static final int CLOSE = 49;
    private static final int NEXT = 53;

    private final int claimId;
    private final Mode mode;
    private final int page;
    private final int pages;
    private final Map<Integer, UUID> slotTargets = new HashMap<>();

    public TrustGUI(ZClaim plugin, Player viewer, Claim claim, Mode mode, int requestedPage) {
        super(plugin);
        this.claimId = claim.getId();
        this.mode = mode;
        GUIManager g = plugin.gui();

        List<UUID> targets = new ArrayList<>();
        Map<UUID, String> names = new HashMap<>();
        if (mode == Mode.TRUSTED) {
            for (Claim.Trust t : claim.getTrusts()) {
                targets.add(t.getUuid());
                names.put(t.getUuid(), t.getName());
            }
        } else {
            for (Player online : Bukkit.getOnlinePlayers()) {
                if (online.getUniqueId().equals(viewer.getUniqueId())) {
                    continue;
                }
                if (mode == Mode.ADD && (claim.isOwner(online.getUniqueId()) || claim.getTrustMask(online.getUniqueId()) != 0)) {
                    continue;
                }
                targets.add(online.getUniqueId());
                names.put(online.getUniqueId(), online.getName());
            }
        }
        targets.sort(Comparator.comparing(u -> names.get(u).toLowerCase()));

        this.pages = Math.max(1, (int) Math.ceil(targets.size() / (double) PER_PAGE));
        this.page = Math.max(0, Math.min(requestedPage, pages - 1));

        Map<String, String> ph = new HashMap<>(g.placeholders(claim));
        ph.put("page", String.valueOf(page + 1));
        ph.put("pages", String.valueOf(pages));
        String titleKey = mode == Mode.TRUSTED ? "title" : mode == Mode.ADD ? "add-title" : "transfer-title";
        String title = ItemBuilder.replace(plugin.getConfig().getString("gui.trust." + titleKey, "ZClaim"), ph);
        this.inventory = Bukkit.createInventory(this, 54, MessageUtils.color(title));
        g.fill(inventory);
        for (int i = 0; i < PER_PAGE; i++) {
            inventory.setItem(i, null);
        }

        int start = page * PER_PAGE;
        for (int i = 0; i < PER_PAGE && start + i < targets.size(); i++) {
            UUID uuid = targets.get(start + i);
            OfflinePlayer op = Bukkit.getOfflinePlayer(uuid);
            Map<String, String> itemPh = new HashMap<>(ph);
            itemPh.put("player", names.get(uuid));
            itemPh.put("levels", plugin.trust().describe(claim.getTrustMask(uuid)));
            String path = mode == Mode.TRUSTED ? "trust.player" : "trust.online-player";
            inventory.setItem(i, g.builder(path, Material.PLAYER_HEAD, itemPh).skull(op).build());
            slotTargets.put(i, uuid);
        }

        if (page > 0) {
            inventory.setItem(PREVIOUS, g.previous(page));
        }
        if (mode == Mode.TRUSTED) {
            inventory.setItem(ADD_BUTTON, g.item("trust.add-button", Material.EMERALD, ph));
        }
        inventory.setItem(BACK, g.back());
        inventory.setItem(CLOSE, g.close());
        if (page < pages - 1) {
            inventory.setItem(NEXT, g.next(page + 2));
        }
    }

    @Override
    public void click(Player p, int slot, ClickType type) {
        Claim c = plugin.cache().getById(claimId);
        if (c == null) {
            p.closeInventory();
            plugin.messages().send(p, "general.claim-not-found");
            return;
        }
        GUIManager g = plugin.gui();
        if (slot == CLOSE) {
            p.closeInventory();
            return;
        }
        if (slot == BACK) {
            if (mode == Mode.TRUSTED) {
                g.openMenu(p, c);
            } else {
                g.openTrust(p, c, Mode.TRUSTED, 0);
            }
            return;
        }
        if (slot == PREVIOUS && page > 0) {
            g.openTrust(p, c, mode, page - 1);
            return;
        }
        if (slot == NEXT && page < pages - 1) {
            g.openTrust(p, c, mode, page + 1);
            return;
        }
        if (slot == ADD_BUTTON && mode == Mode.TRUSTED) {
            if (!p.hasPermission("zclaim.trust") || !plugin.claims().canManage(p, c)) {
                plugin.messages().send(p, "general.no-manage");
                return;
            }
            g.openTrust(p, c, Mode.ADD, 0);
            return;
        }
        UUID target = slotTargets.get(slot);
        if (target == null) {
            return;
        }
        switch (mode) {
            case TRUSTED -> {
                if (!type.isRightClick()) {
                    return;
                }
                if (!p.hasPermission("zclaim.trust") || !plugin.claims().canManage(p, c)) {
                    plugin.messages().send(p, "general.no-manage");
                    return;
                }
                Claim.Trust t = c.getTrust(target);
                String name = t == null ? target.toString() : t.getName();
                plugin.trust().revoke(c, target, 15, () -> {
                    plugin.messages().send(p, "trust.removed", "player", name);
                    g.openTrust(p, c, Mode.TRUSTED, page);
                });
            }
            case ADD -> {
                if (!p.hasPermission("zclaim.trust") || !plugin.claims().canManage(p, c)) {
                    plugin.messages().send(p, "general.no-manage");
                    return;
                }
                Player online = Bukkit.getPlayer(target);
                if (online == null) {
                    plugin.messages().send(p, "general.player-not-found", "player", target.toString());
                    return;
                }
                int mask = plugin.trust().defaultMask();
                plugin.trust().grant(c, target, online.getName(), mask, () -> {
                    plugin.messages().send(p, "trust.added", "player", online.getName(),
                            "level", plugin.trust().describe(mask));
                    g.openTrust(p, c, Mode.TRUSTED, 0);
                });
            }
            case TRANSFER -> {
                if (!p.hasPermission("zclaim.manage")) {
                    plugin.messages().send(p, "general.no-permission");
                    return;
                }
                Player online = Bukkit.getPlayer(target);
                if (online == null) {
                    plugin.messages().send(p, "transfer.target-offline");
                    return;
                }
                p.closeInventory();
                plugin.claims().promptTransfer(p, c, online);
            }
        }
    }
}
