package com.zclaim.gui;

import com.zclaim.ZClaim;
import com.zclaim.models.Claim;
import com.zclaim.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ClaimListGUI extends ZGui {

    private static final int PER_PAGE = 45;
    private static final int PREVIOUS = 45;
    private static final int CLOSE = 49;
    private static final int NEXT = 53;

    private final int page;
    private final int pages;
    private final Map<Integer, Integer> slotToClaim = new HashMap<>();

    public ClaimListGUI(ZClaim plugin, Player viewer, int requestedPage) {
        super(plugin);
        GUIManager g = plugin.gui();
        List<Claim> claims = plugin.cache().getByOwner(viewer.getUniqueId());
        this.pages = Math.max(1, (int) Math.ceil(claims.size() / (double) PER_PAGE));
        this.page = Math.max(0, Math.min(requestedPage, pages - 1));

        Map<String, String> titlePh = Map.of("page", String.valueOf(page + 1), "pages", String.valueOf(pages));
        this.inventory = Bukkit.createInventory(this, 54, MessageUtils.color(g.title("list", titlePh)));
        g.fill(inventory);
        for (int i = 0; i < PER_PAGE; i++) {
            inventory.setItem(i, null);
        }
        int start = page * PER_PAGE;
        for (int i = 0; i < PER_PAGE && start + i < claims.size(); i++) {
            Claim c = claims.get(start + i);
            inventory.setItem(i, g.item("list.claim", Material.GRASS_BLOCK, g.placeholders(c)));
            slotToClaim.put(i, c.getId());
        }
        if (page > 0) {
            inventory.setItem(PREVIOUS, g.previous(page));
        }
        inventory.setItem(CLOSE, g.close());
        if (page < pages - 1) {
            inventory.setItem(NEXT, g.next(page + 2));
        }
    }

    @Override
    public void click(Player p, int slot, ClickType type) {
        if (slot == CLOSE) {
            p.closeInventory();
            return;
        }
        if (slot == PREVIOUS && page > 0) {
            plugin.gui().openList(p, page - 1);
            return;
        }
        if (slot == NEXT && page < pages - 1) {
            plugin.gui().openList(p, page + 1);
            return;
        }
        Integer id = slotToClaim.get(slot);
        if (id == null) {
            return;
        }
        Claim c = plugin.cache().getById(id);
        if (c == null || !c.isOwner(p.getUniqueId())) {
            plugin.messages().send(p, "general.claim-not-found");
            plugin.gui().openList(p, page);
            return;
        }
        plugin.gui().openMenu(p, c);
    }
}
