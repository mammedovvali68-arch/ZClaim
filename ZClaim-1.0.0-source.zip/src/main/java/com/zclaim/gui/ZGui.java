package com.zclaim.gui;

import com.zclaim.ZClaim;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/** Tüm ZClaim menülerinin temel sınıfı; envanter sahibi olarak tanınır. */
public abstract class ZGui implements InventoryHolder {

    protected final ZClaim plugin;
    protected Inventory inventory;

    protected ZGui(ZClaim plugin) {
        this.plugin = plugin;
    }

    public abstract void click(Player player, int slot, ClickType type);

    public void open(Player player) {
        player.openInventory(inventory);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
