package com.zclaim.gui;

import com.zclaim.ZClaim;
import com.zclaim.models.Claim;
import com.zclaim.models.ClaimSettings.Flag;
import com.zclaim.utils.ItemBuilder;
import com.zclaim.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;

import java.util.Map;

public final class ClaimSettingsGUI extends ZGui {

    private static final int FIRST_FLAG_SLOT = 10;
    private static final int BACK = 18;
    private static final int CLOSE = 26;

    private final int claimId;

    public ClaimSettingsGUI(ZClaim plugin, Claim claim) {
        super(plugin);
        this.claimId = claim.getId();
        GUIManager g = plugin.gui();
        Map<String, String> ph = g.placeholders(claim);
        this.inventory = Bukkit.createInventory(this, 27, MessageUtils.color(g.title("settings", ph)));
        g.fill(inventory);
        for (Flag flag : Flag.values()) {
            boolean on = claim.getSettings().get(flag);
            String state = plugin.getConfig().getString(on ? "gui.settings.state-on" : "gui.settings.state-off", on ? "ON" : "OFF");
            ItemBuilder b = g.builder("settings.flags." + flag.configKey(), Material.PAPER, ph);
            b.addLore("");
            b.addLore("&7Durum: " + state);
            b.addLore(plugin.getConfig().getString("gui.settings.hint", "&eTıklayarak değiştir"));
            inventory.setItem(FIRST_FLAG_SLOT + flag.ordinal(), b.build());
        }
        inventory.setItem(BACK, g.back());
        inventory.setItem(CLOSE, g.close());
    }

    @Override
    public void click(Player p, int slot, ClickType type) {
        Claim c = plugin.cache().getById(claimId);
        if (c == null) {
            p.closeInventory();
            plugin.messages().send(p, "general.claim-not-found");
            return;
        }
        if (slot == CLOSE) {
            p.closeInventory();
            return;
        }
        if (slot == BACK) {
            plugin.gui().openMenu(p, c);
            return;
        }
        int index = slot - FIRST_FLAG_SLOT;
        Flag[] flags = Flag.values();
        if (index < 0 || index >= flags.length) {
            return;
        }
        if (!p.hasPermission("zclaim.manage") || !plugin.claims().canManage(p, c)) {
            plugin.messages().send(p, "general.no-manage");
            return;
        }
        Flag flag = flags[index];
        boolean newValue = !c.getSettings().get(flag);
        plugin.claims().setFlag(c, flag, newValue, () -> plugin.gui().openSettings(p, c));
    }
}
