package com.zclaim.gui;

import com.zclaim.ZClaim;
import com.zclaim.models.Claim;
import com.zclaim.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;

import java.util.Map;

public final class ClaimMenu extends ZGui {

    private static final int INFO = 10;
    private static final int TRUSTED = 11;
    private static final int SETTINGS = 12;
    private static final int BORDERS = 14;
    private static final int TRANSFER = 15;
    private static final int ABANDON = 16;
    private static final int LIST = 18;
    private static final int CLOSE = 26;

    private final int claimId;

    public ClaimMenu(ZClaim plugin, Claim claim) {
        super(plugin);
        this.claimId = claim.getId();
        GUIManager g = plugin.gui();
        Map<String, String> ph = g.placeholders(claim);
        this.inventory = Bukkit.createInventory(this, 27, MessageUtils.color(g.title("menu", ph)));
        g.fill(inventory);
        inventory.setItem(INFO, g.item("menu.info", Material.BOOK, ph));
        inventory.setItem(TRUSTED, g.builder("menu.trusted", Material.PLAYER_HEAD, ph)
                .skull(Bukkit.getOfflinePlayer(claim.getOwnerUuid())).build());
        inventory.setItem(SETTINGS, g.item("menu.settings", Material.COMPARATOR, ph));
        inventory.setItem(BORDERS, g.item("menu.borders", Material.ENDER_EYE, ph));
        inventory.setItem(TRANSFER, g.item("menu.transfer", Material.NAME_TAG, ph));
        inventory.setItem(ABANDON, g.item("menu.abandon", Material.TNT, ph));
        inventory.setItem(LIST, g.item("menu.list", Material.MAP, ph));
        inventory.setItem(CLOSE, g.close());
    }

    @Override
    public void click(Player p, int slot, ClickType type) {
        MessageUtils m = plugin.messages();
        Claim c = plugin.cache().getById(claimId);
        if (c == null) {
            p.closeInventory();
            m.send(p, "general.claim-not-found");
            return;
        }
        boolean owner = c.isOwner(p.getUniqueId());
        switch (slot) {
            case INFO -> {
                p.closeInventory();
                plugin.claims().sendInfo(p, c);
            }
            case TRUSTED -> {
                if (!p.hasPermission("zclaim.trust")) {
                    m.send(p, "general.no-permission");
                    return;
                }
                plugin.gui().openTrust(p, c, TrustGUI.Mode.TRUSTED, 0);
            }
            case SETTINGS -> {
                if (!p.hasPermission("zclaim.manage")) {
                    m.send(p, "general.no-permission");
                    return;
                }
                if (!plugin.claims().canManage(p, c)) {
                    m.send(p, "general.no-manage");
                    return;
                }
                plugin.gui().openSettings(p, c);
            }
            case BORDERS -> {
                p.closeInventory();
                plugin.borders().show(p, c, owner);
                m.send(p, "show.started");
            }
            case TRANSFER -> {
                if (!p.hasPermission("zclaim.manage")) {
                    m.send(p, "general.no-permission");
                    return;
                }
                if (!owner) {
                    m.send(p, "general.not-owner");
                    return;
                }
                plugin.gui().openTrust(p, c, TrustGUI.Mode.TRANSFER, 0);
            }
            case ABANDON -> {
                if (!p.hasPermission("zclaim.manage")) {
                    m.send(p, "general.no-permission");
                    return;
                }
                if (!owner) {
                    m.send(p, "general.not-owner");
                    return;
                }
                p.closeInventory();
                plugin.claims().promptAbandon(p, c);
            }
            case LIST -> plugin.gui().openList(p, 0);
            case CLOSE -> p.closeInventory();
            default -> {
                // dolgu
            }
        }
    }
}
