package com.zclaim.gui;

import com.zclaim.ZClaim;
import com.zclaim.models.Claim;
import com.zclaim.utils.ItemBuilder;
import com.zclaim.utils.MessageUtils;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class GUIManager {

    private static final long CLICK_COOLDOWN_MS = 200L;

    private final ZClaim plugin;
    private final Map<UUID, Long> lastClick = new HashMap<>();

    public GUIManager(ZClaim plugin) {
        this.plugin = plugin;
    }

    /** Çift tıklama / hızlı tıklama koruması. true: bu tıklama yok sayılmalı. */
    public boolean throttle(UUID uuid) {
        long now = System.currentTimeMillis();
        Long last = lastClick.get(uuid);
        if (last != null && now - last < CLICK_COOLDOWN_MS) {
            return true;
        }
        lastClick.put(uuid, now);
        return false;
    }

    public void forget(UUID uuid) {
        lastClick.remove(uuid);
    }

    // ------------------------------------------------------------- açma yardımcıları

    public void openMenu(Player p, Claim c) {
        new ClaimMenu(plugin, c).open(p);
    }

    public void openList(Player p, int page) {
        new ClaimListGUI(plugin, p, page).open(p);
    }

    public void openSettings(Player p, Claim c) {
        new ClaimSettingsGUI(plugin, c).open(p);
    }

    public void openTrust(Player p, Claim c, TrustGUI.Mode mode, int page) {
        new TrustGUI(plugin, p, c, mode, page).open(p);
    }

    // ------------------------------------------------------------- config yardımcıları

    public Map<String, String> placeholders(Claim c) {
        Map<String, String> ph = new HashMap<>();
        ph.put("id", String.valueOf(c.getId()));
        ph.put("owner", c.getOwnerName());
        ph.put("world", c.getWorldName());
        ph.put("x", String.valueOf(c.getChunkX()));
        ph.put("z", String.valueOf(c.getChunkZ()));
        ph.put("date", MessageUtils.date(c.getCreatedAt()));
        ph.put("trusted", String.valueOf(c.getTrusts().size()));
        return ph;
    }

    public String title(String path, Map<String, String> ph) {
        return ItemBuilder.replace(plugin.getConfig().getString("gui." + path + ".title", "ZClaim"), ph);
    }

    public ItemBuilder builder(String path, Material fallback, Map<String, String> ph) {
        return ItemBuilder.fromSection(plugin.getConfig().getConfigurationSection("gui." + path), fallback, ph);
    }

    public ItemStack item(String path, Material fallback, Map<String, String> ph) {
        return builder(path, fallback, ph).build();
    }

    public void fill(Inventory inv) {
        ItemStack filler = item("filler", Material.GRAY_STAINED_GLASS_PANE, null);
        for (int i = 0; i < inv.getSize(); i++) {
            inv.setItem(i, filler);
        }
    }

    public ItemStack back() {
        return item("back", Material.ARROW, null);
    }

    public ItemStack close() {
        return item("close", Material.BARRIER, null);
    }

    public ItemStack previous(int page) {
        return item("previous", Material.ARROW, Map.of("page", String.valueOf(page)));
    }

    public ItemStack next(int page) {
        return item("next", Material.ARROW, Map.of("page", String.valueOf(page)));
    }
}
