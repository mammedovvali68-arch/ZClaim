package com.zclaim.database;

import com.zclaim.models.Claim;
import com.zclaim.models.ClaimSettings;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * Tek bağlantılı SQLite katmanı. Tüm çağrılar DatabaseManager'ın tek iş parçacıklı
 * yürütücüsü üzerinden yapılır; ana thread bloke edilmez (başlangıçtaki yükleme hariç).
 */
public final class SQLiteStorage {

    private final File file;
    private final Logger logger;
    private Connection conn;

    public SQLiteStorage(File file, Logger logger) {
        this.file = file;
        this.logger = logger;
    }

    public void open() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException ignored) {
            // Sürücü DriverManager ile de bulunabilir.
        }
        conn = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
        try (Statement st = conn.createStatement()) {
            st.execute("PRAGMA foreign_keys = ON");
            st.execute("PRAGMA journal_mode = WAL");
            st.execute("PRAGMA synchronous = NORMAL");
            st.execute("PRAGMA busy_timeout = 5000");

            st.execute("CREATE TABLE IF NOT EXISTS claims ("
                    + "claim_id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "owner_uuid TEXT NOT NULL,"
                    + "owner_name TEXT NOT NULL,"
                    + "world_uuid TEXT NOT NULL,"
                    + "world_name TEXT NOT NULL,"
                    + "chunk_x INTEGER NOT NULL,"
                    + "chunk_z INTEGER NOT NULL,"
                    + "created_at INTEGER NOT NULL,"
                    + "UNIQUE(world_uuid, chunk_x, chunk_z))");
            st.execute("CREATE INDEX IF NOT EXISTS idx_claims_owner ON claims(owner_uuid)");

            st.execute("CREATE TABLE IF NOT EXISTS claim_trusts ("
                    + "claim_id INTEGER NOT NULL,"
                    + "player_uuid TEXT NOT NULL,"
                    + "player_name TEXT NOT NULL,"
                    + "permissions INTEGER NOT NULL,"
                    + "PRIMARY KEY (claim_id, player_uuid),"
                    + "FOREIGN KEY (claim_id) REFERENCES claims(claim_id) ON DELETE CASCADE)");
            st.execute("CREATE INDEX IF NOT EXISTS idx_trusts_player ON claim_trusts(player_uuid)");

            StringBuilder cols = new StringBuilder();
            for (ClaimSettings.Flag f : ClaimSettings.Flag.values()) {
                cols.append(", ").append(f.column()).append(" INTEGER NOT NULL DEFAULT ")
                        .append(f.defaultValue() ? 1 : 0);
            }
            st.execute("CREATE TABLE IF NOT EXISTS claim_settings ("
                    + "claim_id INTEGER PRIMARY KEY" + cols
                    + ", FOREIGN KEY (claim_id) REFERENCES claims(claim_id) ON DELETE CASCADE)");

            st.execute("CREATE TABLE IF NOT EXISTS admin_logs ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "admin_uuid TEXT,"
                    + "admin_name TEXT NOT NULL,"
                    + "action TEXT NOT NULL,"
                    + "claim_id INTEGER,"
                    + "details TEXT,"
                    + "created_at INTEGER NOT NULL)");
        }
    }

    public void close() {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ex) {
                logger.warning("Veritabanı bağlantısı kapatılamadı: " + ex.getMessage());
            }
        }
    }

    public int insertClaim(UUID owner, String ownerName, UUID world, String worldName,
                           int chunkX, int chunkZ, long createdAt, ClaimSettings settings) throws SQLException {
        boolean previousAutoCommit = conn.getAutoCommit();
        conn.setAutoCommit(false);
        try {
            int id;
            try (PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO claims (owner_uuid, owner_name, world_uuid, world_name, chunk_x, chunk_z, created_at)"
                            + " VALUES (?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, owner.toString());
                ps.setString(2, ownerName);
                ps.setString(3, world.toString());
                ps.setString(4, worldName);
                ps.setInt(5, chunkX);
                ps.setInt(6, chunkZ);
                ps.setLong(7, createdAt);
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (!rs.next()) {
                        throw new SQLException("Claim ID alınamadı.");
                    }
                    id = rs.getInt(1);
                }
            }

            StringBuilder cols = new StringBuilder("claim_id");
            StringBuilder marks = new StringBuilder("?");
            for (ClaimSettings.Flag f : ClaimSettings.Flag.values()) {
                cols.append(", ").append(f.column());
                marks.append(", ?");
            }
            try (PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO claim_settings (" + cols + ") VALUES (" + marks + ")")) {
                ps.setInt(1, id);
                int i = 2;
                for (ClaimSettings.Flag f : ClaimSettings.Flag.values()) {
                    ps.setInt(i++, settings.get(f) ? 1 : 0);
                }
                ps.executeUpdate();
            }
            conn.commit();
            return id;
        } catch (SQLException ex) {
            conn.rollback();
            throw ex;
        } finally {
            conn.setAutoCommit(previousAutoCommit);
        }
    }

    public void deleteClaim(int claimId) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("DELETE FROM claims WHERE claim_id = ?")) {
            ps.setInt(1, claimId);
            ps.executeUpdate();
        }
    }

    public void transferOwner(int claimId, UUID newOwner, String newName) throws SQLException {
        boolean previousAutoCommit = conn.getAutoCommit();
        conn.setAutoCommit(false);
        try {
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE claims SET owner_uuid = ?, owner_name = ? WHERE claim_id = ?")) {
                ps.setString(1, newOwner.toString());
                ps.setString(2, newName);
                ps.setInt(3, claimId);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = conn.prepareStatement(
                    "DELETE FROM claim_trusts WHERE claim_id = ? AND player_uuid = ?")) {
                ps.setInt(1, claimId);
                ps.setString(2, newOwner.toString());
                ps.executeUpdate();
            }
            conn.commit();
        } catch (SQLException ex) {
            conn.rollback();
            throw ex;
        } finally {
            conn.setAutoCommit(previousAutoCommit);
        }
    }

    public void saveTrust(int claimId, UUID player, String name, int mask) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO claim_trusts (claim_id, player_uuid, player_name, permissions) VALUES (?,?,?,?)"
                        + " ON CONFLICT(claim_id, player_uuid) DO UPDATE SET"
                        + " player_name = excluded.player_name, permissions = excluded.permissions")) {
            ps.setInt(1, claimId);
            ps.setString(2, player.toString());
            ps.setString(3, name);
            ps.setInt(4, mask);
            ps.executeUpdate();
        }
    }

    public void deleteTrust(int claimId, UUID player) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "DELETE FROM claim_trusts WHERE claim_id = ? AND player_uuid = ?")) {
            ps.setInt(1, claimId);
            ps.setString(2, player.toString());
            ps.executeUpdate();
        }
    }

    public void updateFlag(int claimId, ClaimSettings.Flag flag, boolean value) throws SQLException {
        // Sütun adı enum'dan gelir, kullanıcı girdisi değildir.
        try (PreparedStatement ps = conn.prepareStatement(
                "UPDATE claim_settings SET " + flag.column() + " = ? WHERE claim_id = ?")) {
            ps.setInt(1, value ? 1 : 0);
            ps.setInt(2, claimId);
            ps.executeUpdate();
        }
    }

    public void logAdmin(UUID adminUuid, String adminName, String action, Integer claimId,
                         String details, long createdAt) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO admin_logs (admin_uuid, admin_name, action, claim_id, details, created_at)"
                        + " VALUES (?,?,?,?,?,?)")) {
            ps.setString(1, adminUuid == null ? null : adminUuid.toString());
            ps.setString(2, adminName);
            ps.setString(3, action);
            if (claimId == null) {
                ps.setNull(4, java.sql.Types.INTEGER);
            } else {
                ps.setInt(4, claimId);
            }
            ps.setString(5, details);
            ps.setLong(6, createdAt);
            ps.executeUpdate();
        }
    }

    public List<Claim> loadAll() throws SQLException {
        Map<Integer, ClaimSettings> settingsById = new HashMap<>();
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM claim_settings")) {
            while (rs.next()) {
                ClaimSettings s = new ClaimSettings();
                for (ClaimSettings.Flag f : ClaimSettings.Flag.values()) {
                    s.set(f, rs.getInt(f.column()) != 0);
                }
                settingsById.put(rs.getInt("claim_id"), s);
            }
        }

        Map<Integer, Claim> claims = new HashMap<>();
        List<Claim> result = new ArrayList<>();
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM claims")) {
            while (rs.next()) {
                int id = rs.getInt("claim_id");
                try {
                    ClaimSettings s = settingsById.get(id);
                    if (s == null) {
                        s = new ClaimSettings();
                    }
                    Claim c = new Claim(id,
                            UUID.fromString(rs.getString("owner_uuid")),
                            rs.getString("owner_name"),
                            UUID.fromString(rs.getString("world_uuid")),
                            rs.getString("world_name"),
                            rs.getInt("chunk_x"),
                            rs.getInt("chunk_z"),
                            rs.getLong("created_at"),
                            s);
                    claims.put(id, c);
                    result.add(c);
                } catch (IllegalArgumentException ex) {
                    logger.warning("Bozuk claim kaydı atlandı (ID " + id + "): " + ex.getMessage());
                }
            }
        }

        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT claim_id, player_uuid, player_name, permissions FROM claim_trusts")) {
            while (rs.next()) {
                Claim c = claims.get(rs.getInt("claim_id"));
                if (c == null) {
                    continue;
                }
                try {
                    c.setTrust(UUID.fromString(rs.getString("player_uuid")),
                            rs.getString("player_name"), rs.getInt("permissions"));
                } catch (IllegalArgumentException ex) {
                    logger.warning("Bozuk trust kaydı atlandı: " + ex.getMessage());
                }
            }
        }
        return result;
    }
}
