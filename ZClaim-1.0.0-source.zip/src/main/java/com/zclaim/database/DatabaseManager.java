package com.zclaim.database;

import com.zclaim.ZClaim;

import java.io.File;
import java.sql.SQLException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;

public final class DatabaseManager {

    @FunctionalInterface
    public interface SqlTask<T> {
        T run(SQLiteStorage storage) throws SQLException;
    }

    @FunctionalInterface
    public interface SqlRunnable {
        void run(SQLiteStorage storage) throws SQLException;
    }

    private final ZClaim plugin;
    private SQLiteStorage storage;
    private ExecutorService executor;

    public DatabaseManager(ZClaim plugin) {
        this.plugin = plugin;
    }

    public void init() throws SQLException {
        File dir = plugin.getDataFolder();
        if (!dir.exists() && !dir.mkdirs()) {
            throw new SQLException("Veri klasörü oluşturulamadı: " + dir);
        }
        storage = new SQLiteStorage(new File(dir, "zclaim.db"), plugin.getLogger());
        storage.open();
        executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "ZClaim-DB");
            t.setDaemon(false);
            return t;
        });
    }

    /** Yalnızca başlangıçta (executor boştayken) ana thread'den kullanılır. */
    public SQLiteStorage storage() {
        return storage;
    }

    public <T> CompletableFuture<T> supply(SqlTask<T> task) {
        try {
            return CompletableFuture.supplyAsync(() -> {
                try {
                    return task.run(storage);
                } catch (SQLException ex) {
                    throw new CompletionException(ex);
                }
            }, executor);
        } catch (RejectedExecutionException ex) {
            return CompletableFuture.failedFuture(ex);
        }
    }

    public CompletableFuture<Void> run(SqlRunnable task) {
        return this.<Void>supply(s -> {
            task.run(s);
            return null;
        });
    }

    public void shutdown() {
        if (executor != null) {
            executor.shutdown();
            try {
                if (!executor.awaitTermination(15, TimeUnit.SECONDS)) {
                    plugin.getLogger().warning("Bekleyen veritabanı işlemleri zamanında bitmedi.");
                }
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }
        }
        if (storage != null) {
            storage.close();
        }
    }
}
