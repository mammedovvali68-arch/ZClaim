package com.zclaim.commands;

import com.zclaim.ZClaim;
import com.zclaim.models.Claim;
import com.zclaim.utils.MessageUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ClaimAdminCommand implements TabExecutor {

    private static final List<String> SUBS = List.of("bypass", "info", "delete", "list", "reload", "protect");
    private static final int PER_PAGE = 10;

    private final ZClaim plugin;

    public ClaimAdminCommand(ZClaim plugin) {
        this.plugin = plugin;
    }

    private MessageUtils m() {
        return plugin.messages();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            m().send(sender, "admin.usage");
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        String perm = switch (sub) {
            case "bypass" -> "zclaim.bypass";
            case "delete" -> "zclaim.admin.delete";
            case "info", "list", "reload", "protect" -> "zclaim.admin";
            default -> null;
        };
        if (perm == null) {
            m().send(sender, "admin.usage");
            return true;
        }
        if (!sender.hasPermission(perm)) {
            m().send(sender, "general.no-permission");
            return true;
        }
        switch (sub) {
            case "bypass" -> bypass(sender);
            case "info" -> info(sender, args);
            case "delete" -> delete(sender, args);
            case "list" -> list(sender, args);
            case "protect" -> protect(sender);
            case "reload" -> {
                plugin.reloadAll();
                m().send(sender, "admin.reloaded");
                plugin.claims().logAdmin(sender, "RELOAD", null, null);
            }
            default -> m().send(sender, "admin.usage");
        }
        return true;
    }

    private void bypass(CommandSender sender) {
        if (!(sender instanceof Player p)) {
            m().send(sender, "general.players-only");
            return;
        }
        boolean on = plugin.protection().toggleBypass(p);
        m().send(p, on ? "admin.bypass-on" : "admin.bypass-off");
        plugin.claims().logAdmin(sender, on ? "BYPASS_ON" : "BYPASS_OFF", null, null);
    }

    /** Argümanda ID varsa onu, yoksa oyuncunun bulunduğu claimi döndürür. */
    private Claim target(CommandSender sender, String[] args) {
        if (args.length > 1) {
            try {
                Claim c = plugin.cache().getById(Integer.parseInt(args[1]));
                if (c == null) {
                    m().send(sender, "general.claim-not-found");
                }
                return c;
            } catch (NumberFormatException ex) {
                m().send(sender, "general.invalid-number");
                return null;
            }
        }
        if (sender instanceof Player p) {
            Claim c = plugin.claims().getClaimAt(p.getLocation());
            if (c == null) {
                m().send(sender, "general.not-in-claim");
            }
            return c;
        }
        m().send(sender, "general.players-only");
        return null;
    }

    private void info(CommandSender sender, String[] args) {
        Claim c = target(sender, args);
        if (c == null) {
            return;
        }
        m().sendLines(sender, "admin.info-lines", plugin.claims().placeholders(c));
        for (Claim.Trust t : c.getTrusts()) {
            m().send(sender, "trust.list-entry", "player", t.getName(), "levels", plugin.trust().describe(t.getMask()));
        }
        plugin.claims().logAdmin(sender, "INFO", c.getId(), null);
    }

    private void delete(CommandSender sender, String[] args) {
        Claim c = target(sender, args);
        if (c == null) {
            return;
        }
        final int id = c.getId();
        final String details = c.getOwnerName() + " " + c.getWorldName() + " " + c.getChunkX() + "," + c.getChunkZ();
        plugin.claims().deleteClaim(c, ok -> {
            if (ok) {
                m().send(sender, "admin.deleted", "id", String.valueOf(id));
                plugin.claims().logAdmin(sender, "DELETE", id, details);
            } else {
                m().send(sender, "admin.delete-failed");
            }
        });
    }

    private void list(CommandSender sender, String[] args) {
        int page = 1;
        if (args.length > 1) {
            try {
                page = Math.max(1, Integer.parseInt(args[1]));
            } catch (NumberFormatException ex) {
                m().send(sender, "general.invalid-number");
                return;
            }
        }
        List<Claim> all = plugin.cache().all();
        int pages = Math.max(1, (int) Math.ceil(all.size() / (double) PER_PAGE));
        page = Math.min(page, pages);
        m().send(sender, "admin.list-header", "page", String.valueOf(page), "pages", String.valueOf(pages));
        for (int i = (page - 1) * PER_PAGE; i < Math.min(all.size(), page * PER_PAGE); i++) {
            m().send(sender, "admin.list-entry", plugin.claims().placeholders(all.get(i)));
        }
    }

    private void protect(CommandSender sender) {
        if (!(sender instanceof Player p)) {
            m().send(sender, "general.players-only");
            return;
        }
        plugin.claims().createServerClaim(p);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : SUBS) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) {
                    out.add(s);
                }
            }
        }
        return out;
    }
}
