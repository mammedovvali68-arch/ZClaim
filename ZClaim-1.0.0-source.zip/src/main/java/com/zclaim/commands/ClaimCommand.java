package com.zclaim.commands;

import com.zclaim.ZClaim;
import com.zclaim.managers.ClaimManager;
import com.zclaim.models.Claim;
import com.zclaim.models.ClaimPermission;
import com.zclaim.utils.MessageUtils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class ClaimCommand implements TabExecutor {

    private static final List<String> SUBS = List.of(
            "info", "list", "trust", "untrust", "trustlist", "abandon", "transfer", "show", "settings", "menu", "help");
    private static final List<String> LEVELS = List.of("build", "container", "access", "manage");
    private static final int PER_PAGE = 8;

    private final ZClaim plugin;

    public ClaimCommand(ZClaim plugin) {
        this.plugin = plugin;
    }

    private MessageUtils m() {
        return plugin.messages();
    }

    private ClaimManager claims() {
        return plugin.claims();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            m().send(sender, "general.players-only");
            return true;
        }
        if (args.length == 0) {
            if (!p.hasPermission("zclaim.claim")) {
                m().send(p, "general.no-permission");
                return true;
            }
            claims().createClaim(p);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        String perm = switch (sub) {
            case "info", "list", "show", "menu", "help" -> "zclaim.claim";
            case "trust", "untrust", "trustlist" -> "zclaim.trust";
            case "settings", "abandon", "transfer" -> "zclaim.manage";
            default -> null;
        };
        if (perm == null) {
            m().send(p, "general.unknown-sub");
            return true;
        }
        if (!p.hasPermission(perm)) {
            m().send(p, "general.no-permission");
            return true;
        }
        switch (sub) {
            case "help" -> m().sendLines(p, "help");
            case "info" -> info(p, args);
            case "list" -> list(p, args);
            case "trust" -> trust(p, args);
            case "untrust" -> untrust(p, args);
            case "trustlist" -> trustList(p);
            case "abandon" -> abandon(p, args);
            case "transfer" -> transfer(p, args);
            case "show" -> show(p);
            case "settings" -> settings(p);
            case "menu" -> menu(p);
            default -> m().send(p, "general.unknown-sub");
        }
        return true;
    }

    // ---------------------------------------------------------------- yardımcılar

    private Claim here(Player p) {
        Claim c = claims().getClaimAt(p.getLocation());
        if (c == null) {
            m().send(p, "general.not-in-claim");
        }
        return c;
    }

    private OfflinePlayer findPlayer(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            return online;
        }
        return Bukkit.getOfflinePlayerIfCached(name);
    }

    // ---------------------------------------------------------------- alt komutlar

    private void info(Player p, String[] args) {
        Claim c;
        if (args.length > 1) {
            try {
                c = plugin.cache().getById(Integer.parseInt(args[1]));
            } catch (NumberFormatException ex) {
                m().send(p, "general.invalid-number");
                return;
            }
            if (c == null || !(c.isOwner(p.getUniqueId()) || p.hasPermission("zclaim.admin"))) {
                m().send(p, "general.claim-not-found");
                return;
            }
        } else {
            c = here(p);
            if (c == null) {
                return;
            }
        }
        claims().sendInfo(p, c);
    }

    private void list(Player p, String[] args) {
        if (args.length > 1 && args[1].equalsIgnoreCase("gui")) {
            plugin.gui().openList(p, 0);
            return;
        }
        int page = 1;
        if (args.length > 1) {
            try {
                page = Math.max(1, Integer.parseInt(args[1]));
            } catch (NumberFormatException ex) {
                m().send(p, "general.invalid-number");
                return;
            }
        }
        List<Claim> all = plugin.cache().getByOwner(p.getUniqueId());
        if (all.isEmpty()) {
            m().send(p, "list.empty");
            return;
        }
        int pages = (int) Math.ceil(all.size() / (double) PER_PAGE);
        page = Math.min(page, pages);
        p.sendMessage(MessageUtils.color(m().get("list.header", "page", String.valueOf(page), "pages", String.valueOf(pages))));
        for (int i = (page - 1) * PER_PAGE; i < Math.min(all.size(), page * PER_PAGE); i++) {
            Claim c = all.get(i);
            String[] ph = claims().placeholders(c);
            Component line = MessageUtils.color(MessageUtils.apply(m().raw("list.entry"), ph))
                    .clickEvent(ClickEvent.runCommand("/claim info " + c.getId()))
                    .hoverEvent(HoverEvent.showText(MessageUtils.color(m().raw("list.entry-hover"))));
            p.sendMessage(line);
        }
        m().send(p, "list.footer", "total", String.valueOf(all.size()));
    }

    private void trust(Player p, String[] args) {
        if (args.length < 2) {
            m().send(p, "general.usage", "usage", m().get("trust.usage"));
            return;
        }
        Claim c = here(p);
        if (c == null) {
            return;
        }
        if (c.isServerOwned()) {
            m().send(p, "trust.server-claim");
            return;
        }
        if (!claims().canManage(p, c)) {
            m().send(p, "general.no-manage");
            return;
        }
        OfflinePlayer target = findPlayer(args[1]);
        if (target == null) {
            m().send(p, "general.player-not-found", "player", args[1]);
            return;
        }
        if (target.getUniqueId().equals(p.getUniqueId()) || c.isOwner(target.getUniqueId())) {
            m().send(p, "trust.self");
            return;
        }
        int mask;
        if (args.length > 2) {
            ClaimPermission level = ClaimPermission.parse(args[2]);
            if (level == null) {
                m().send(p, "trust.invalid-level");
                return;
            }
            mask = level.bit();
        } else {
            mask = plugin.trust().defaultMask();
        }
        String name = target.getName() == null ? args[1] : target.getName();
        final int finalMask = mask;
        plugin.trust().grant(c, target.getUniqueId(), name, mask, () -> {
            String levels = plugin.trust().describe(finalMask);
            m().send(p, "trust.added", "player", name, "level", levels);
            Player online = target.getPlayer();
            if (online != null) {
                m().send(online, "trust.received", "owner", p.getName(), "level", levels,
                        "world", c.getWorldName(), "x", String.valueOf(c.getChunkX()), "z", String.valueOf(c.getChunkZ()));
            }
        });
    }

    private void untrust(Player p, String[] args) {
        if (args.length < 2) {
            m().send(p, "general.usage", "usage", m().get("trust.untrust-usage"));
            return;
        }
        Claim c = here(p);
        if (c == null) {
            return;
        }
        if (!claims().canManage(p, c)) {
            m().send(p, "general.no-manage");
            return;
        }
        UUID target = null;
        for (Claim.Trust t : c.getTrusts()) {
            if (t.getName().equalsIgnoreCase(args[1])) {
                target = t.getUuid();
                break;
            }
        }
        if (target == null) {
            m().send(p, "trust.not-trusted", "player", args[1]);
            return;
        }
        int removeMask = ClaimPermission.ALL_BITS;
        if (args.length > 2) {
            ClaimPermission level = ClaimPermission.parse(args[2]);
            if (level == null) {
                m().send(p, "trust.invalid-level");
                return;
            }
            removeMask = level.bit();
        }
        final String name = args[1];
        plugin.trust().revoke(c, target, removeMask, () -> m().send(p, "trust.removed", "player", name));
    }

    private void trustList(Player p) {
        Claim c = here(p);
        if (c == null) {
            return;
        }
        if (!c.isOwner(p.getUniqueId()) && c.getTrustMask(p.getUniqueId()) == 0 && !p.hasPermission("zclaim.admin")) {
            m().send(p, "general.no-manage");
            return;
        }
        m().send(p, "trust.list-header", "count", String.valueOf(c.getTrusts().size()));
        if (c.getTrusts().isEmpty()) {
            m().send(p, "trust.list-empty");
            return;
        }
        for (Claim.Trust t : c.getTrusts()) {
            m().send(p, "trust.list-entry", "player", t.getName(), "levels", plugin.trust().describe(t.getMask()));
        }
    }

    private void abandon(Player p, String[] args) {
        if (args.length > 1 && args[1].equalsIgnoreCase("confirm")) {
            claims().confirmAbandon(p);
            return;
        }
        if (args.length > 1 && args[1].equalsIgnoreCase("cancel")) {
            claims().cancelPending(p, false);
            return;
        }
        Claim c = here(p);
        if (c != null) {
            claims().promptAbandon(p, c);
        }
    }

    private void transfer(Player p, String[] args) {
        if (args.length < 2) {
            m().send(p, "general.usage", "usage", m().get("transfer.usage"));
            return;
        }
        if (args[1].equalsIgnoreCase("confirm")) {
            claims().confirmTransfer(p);
            return;
        }
        if (args[1].equalsIgnoreCase("cancel")) {
            claims().cancelPending(p, true);
            return;
        }
        Claim c = here(p);
        if (c == null) {
            return;
        }
        if (!c.isOwner(p.getUniqueId())) {
            m().send(p, "general.not-owner");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            m().send(p, "transfer.target-offline");
            return;
        }
        claims().promptTransfer(p, c, target);
    }

    private void show(Player p) {
        if (!plugin.borders().isEnabled()) {
            m().send(p, "show.disabled");
            return;
        }
        Claim c = here(p);
        if (c == null) {
            return;
        }
        boolean owner = c.isOwner(p.getUniqueId());
        if (!owner && c.getTrustMask(p.getUniqueId()) == 0 && !p.hasPermission("zclaim.admin")) {
            m().send(p, "show.no-access");
            return;
        }
        if (!p.getWorld().getUID().equals(c.getWorldUuid())) {
            m().send(p, "show.other-world");
            return;
        }
        plugin.borders().show(p, c, owner);
        m().send(p, "show.started");
    }

    private void settings(Player p) {
        Claim c = here(p);
        if (c == null) {
            return;
        }
        if (!claims().canManage(p, c)) {
            m().send(p, "general.no-manage");
            return;
        }
        plugin.gui().openSettings(p, c);
    }

    private void menu(Player p) {
        Claim c = here(p);
        if (c == null) {
            return;
        }
        if (!claims().canManage(p, c)) {
            m().send(p, "general.no-manage");
            return;
        }
        plugin.gui().openMenu(p, c);
    }

    // ---------------------------------------------------------------- tab

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            addMatching(out, SUBS, args[0]);
        } else if (args.length == 2) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            if (sub.equals("trust") || sub.equals("transfer")) {
                for (Player pl : Bukkit.getOnlinePlayers()) {
                    if (pl.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) {
                        out.add(pl.getName());
                    }
                }
                if (sub.equals("transfer")) {
                    addMatching(out, List.of("confirm", "cancel"), args[1]);
                }
            } else if (sub.equals("untrust") && sender instanceof Player p) {
                Claim c = plugin.claims().getClaimAt(p.getLocation());
                if (c != null) {
                    for (Claim.Trust t : c.getTrusts()) {
                        if (t.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) {
                            out.add(t.getName());
                        }
                    }
                }
            } else if (sub.equals("abandon")) {
                addMatching(out, List.of("confirm", "cancel"), args[1]);
            } else if (sub.equals("list")) {
                addMatching(out, List.of("gui"), args[1]);
            }
        } else if (args.length == 3) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            if (sub.equals("trust") || sub.equals("untrust")) {
                addMatching(out, LEVELS, args[2]);
            }
        }
        return out;
    }

    private static void addMatching(List<String> out, List<String> options, String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        for (String o : options) {
            if (o.startsWith(lower)) {
                out.add(o);
            }
        }
    }
}
